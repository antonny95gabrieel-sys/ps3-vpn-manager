#include "vpn_state.h"

vpn_state_t vpn_state_transition(vpn_state_t current, vpn_event_t event)
{
    switch (current) {
    case VPN_STATE_DISCONNECTED:
        if (event == VPN_EVENT_CONFIG_VALID) return VPN_STATE_CONFIGURED;
        if (event == VPN_EVENT_RESET) return VPN_STATE_DISCONNECTED;
        break;
    case VPN_STATE_CONFIGURED:
        if (event == VPN_EVENT_CONNECT_REQUEST) return VPN_STATE_CONNECTING;
        if (event == VPN_EVENT_RESET) return VPN_STATE_DISCONNECTED;
        break;
    case VPN_STATE_CONNECTING:
        if (event == VPN_EVENT_HANDSHAKE_OK) return VPN_STATE_CONNECTED;
        if (event == VPN_EVENT_HANDSHAKE_FAILED) return VPN_STATE_ERROR;
        if (event == VPN_EVENT_DISCONNECT_REQUEST) return VPN_STATE_DISCONNECTING;
        break;
    case VPN_STATE_CONNECTED:
        if (event == VPN_EVENT_DISCONNECT_REQUEST) return VPN_STATE_DISCONNECTING;
        if (event == VPN_EVENT_HANDSHAKE_FAILED) return VPN_STATE_ERROR;
        break;
    case VPN_STATE_DISCONNECTING:
        if (event == VPN_EVENT_TUNNEL_CLOSED) return VPN_STATE_CONFIGURED;
        if (event == VPN_EVENT_HANDSHAKE_FAILED) return VPN_STATE_ERROR;
        break;
    case VPN_STATE_ERROR:
        if (event == VPN_EVENT_RESET) return VPN_STATE_DISCONNECTED;
        if (event == VPN_EVENT_TUNNEL_CLOSED) return VPN_STATE_CONFIGURED;
        break;
    default:
        break;
    }
    return current;
}

const char *vpn_state_name(vpn_state_t state)
{
    switch (state) {
    case VPN_STATE_DISCONNECTED: return "Desconectado";
    case VPN_STATE_CONFIGURED: return "Configurado";
    case VPN_STATE_CONNECTING: return "Conectando";
    case VPN_STATE_CONNECTED: return "Conectado";
    case VPN_STATE_DISCONNECTING: return "Desconectando";
    case VPN_STATE_ERROR: return "Erro";
    default: return "Estado desconhecido";
    }
}
