#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP/bin" "$TMP/portlibs/include" "$TMP/psl1ght/ppu/include"
: > "$TMP/portlibs/include/tiny3d.h"
: > "$TMP/portlibs/include/libfont.h"
cat > "$TMP/bin/ppu-gcc" <<'MOCK'
#!/bin/sh
printf '%s\n' "$*" > "$PROBE_LOG"
MOCK
chmod +x "$TMP/bin/ppu-gcc"
export PATH="$TMP/bin:$PATH"
export PROBE_LOG="$TMP/ppu-gcc-args.txt"
export PS3DEV="$TMP/ps3dev"
export PSL1GHT="$TMP/psl1ght"
export PORTLIBS="$TMP/portlibs"
(cd "$ROOT" && ./tools/check-tiny3d-headers.sh)
grep -q -- '-fsyntax-only' "$PROBE_LOG"
grep -q 'tiny3d_header_probe.c' "$PROBE_LOG"
printf 'OK: teste do contrato do probe Tiny3D.\n'
