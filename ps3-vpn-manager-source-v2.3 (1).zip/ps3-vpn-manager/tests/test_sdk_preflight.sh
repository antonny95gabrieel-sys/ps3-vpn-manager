#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP/bin" "$TMP/ps3dev/bin" "$TMP/psl1ght/ppu/include/io" \
  "$TMP/psl1ght/ppu/include/sysutil" "$TMP/psl1ght/ppu/lib" \
  "$TMP/portlibs/include" "$TMP/portlibs/lib"

cat > "$TMP/bin/ppu-gcc" <<'MOCK'
#!/bin/sh
printf 'ppu-gcc mock 1.0\n'
MOCK
chmod +x "$TMP/bin/ppu-gcc"
: > "$TMP/psl1ght/ppu_rules"
: > "$TMP/psl1ght/base_rules"
: > "$TMP/psl1ght/ppu/include/io/pad.h"
: > "$TMP/psl1ght/ppu/include/sysutil/sysutil.h"
: > "$TMP/psl1ght/ppu/lib/libio.a"
: > "$TMP/psl1ght/ppu/lib/libsysutil.a"
: > "$TMP/portlibs/include/tiny3d.h"
: > "$TMP/portlibs/lib/libtiny3d.a"
: > "$TMP/portlibs/include/libfont.h"
: > "$TMP/portlibs/lib/libfont.a"

export PATH="$TMP/bin:$PATH"
export PS3DEV="$TMP/ps3dev" PSL1GHT="$TMP/psl1ght" PORTLIBS="$TMP/portlibs"
"$ROOT/tools/check-ps3-sdk.sh" --core >/dev/null
"$ROOT/tools/check-ps3-sdk.sh" --graphics >/dev/null
if "$ROOT/tools/check-ps3-sdk.sh" --package >/dev/null 2>&1; then
  echo 'ERRO: modo package aceitou ferramentas ausentes' >&2
  exit 1
fi
printf 'OK: preflight distingue dependencias core, grafica e pacote.\n'
