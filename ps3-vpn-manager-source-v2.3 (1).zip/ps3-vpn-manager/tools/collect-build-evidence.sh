#!/bin/sh
# Create a deterministic SHA-256 inventory of the PS3 VPN Manager build evidence.
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT_DIR=${1:-"$ROOT/build-evidence"}
case "$OUT_DIR" in
  /*) ;;
  *) OUT_DIR="$ROOT/$OUT_DIR" ;;
esac

FILES="build-evidence/ps3vpnmanager.elf
build-evidence/ps3vpnmanager.self
build-evidence/ps3vpnmanager.pkg
ps3dev-revision.txt
tiny3d-revision.txt
psl1ght-revision.txt
build-evidence/ps3dev-build.log
build-evidence/ps3-sdk-core.log
build-evidence/ps3-sdk-graphics.log
build-evidence/psl1ght-build-install.log
build-evidence/ps3-vpn-manager-build.log
build-evidence/ps3-vpn-manager-package.log"

command -v sha256sum >/dev/null 2>&1 || {
  echo "ERRO: sha256sum não encontrado." >&2
  exit 1
}

mkdir -p "$OUT_DIR"
MANIFEST="$OUT_DIR/manifest.sha256.tsv"
TMP="$MANIFEST.tmp"
trap 'rm -f "$TMP"' EXIT HUP INT TERM

{
  printf 'format\tps3-vpn-manager-build-evidence-v2\n'
  printf 'file\tbytes\tsha256\n'
  printf '%s\n' "$FILES" | while IFS= read -r rel; do
    [ -n "$rel" ] || continue
    path="$ROOT/$rel"
    if [ ! -s "$path" ]; then
      printf 'ERRO: arquivo de evidência ausente ou vazio: %s\n' "$rel" >&2
      exit 1
    fi
    bytes=$(wc -c < "$path" | tr -d '[:space:]')
    hash=$(sha256sum "$path" | awk '{print $1}')
    printf '%s\t%s\t%s\n' "$rel" "$bytes" "$hash"
  done
} > "$TMP"

mv "$TMP" "$MANIFEST"
printf 'Manifesto SHA-256 criado: %s\n' "$MANIFEST"
