# Desenvolvimento sem computador local

O usuário não dispõe de computador. O assistente pode preparar e validar código-fonte e arquivos do projeto no ambiente de trabalho, mas a compilação final para PS3 requer uma toolchain PS3 compatível (PS3DEV/PSL1GHT, compilador PPU, ferramentas SELF e empacotador PKG). Não afirmar que um ZIP de fontes é instalável.

Possíveis caminhos:

1. Conseguir acesso temporário a um computador Windows/Linux para compilar com a toolchain.
2. Usar um serviço de compilação remoto confiável, depois de auditar o código e proteger quaisquer credenciais.
3. Adaptar o projeto a um repositório público e usar CI, se o ambiente de CI suportar a toolchain e as ferramentas necessárias.

Não pedir ao usuário que envie chave privada WireGuard. Para testes, usar configuração fictícia e chaves de laboratório.
