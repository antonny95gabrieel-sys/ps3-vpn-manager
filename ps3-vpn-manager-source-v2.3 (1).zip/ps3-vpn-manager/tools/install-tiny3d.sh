#!/bin/sh
# Build and install only Tiny3D libraries; samples are intentionally skipped.
set -eu

SOURCE_DIR=${1:-}

fail() {
  printf 'ERRO: %s\n' "$1" >&2
  exit 1
}

[ -n "$SOURCE_DIR" ] || fail "uso: $0 DIRETORIO_DO_TINY3D"
[ -d "$SOURCE_DIR" ] || fail "diretorio Tiny3D inexistente: $SOURCE_DIR"
[ -f "$SOURCE_DIR/Makefile" ] || fail "Makefile principal do Tiny3D ausente"
[ -f "$SOURCE_DIR/lib/Makefile" ] || fail "Makefile da biblioteca Tiny3D ausente"
[ -f "$SOURCE_DIR/libfont/Makefile" ] || fail "Makefile da libfont ausente"

: "${PSL1GHT:?Defina PSL1GHT para a raiz do PSL1GHT}"
: "${PS3DEV:?Defina PS3DEV para a raiz do ps3dev}"
: "${PORTLIBS:=$PS3DEV/portlibs/ppu}"

command -v make >/dev/null 2>&1 || fail "comando make ausente"

printf 'Construindo biblioteca Tiny3D...\n'
make -C "$SOURCE_DIR/lib" install
printf 'Construindo biblioteca de fontes Tiny3D...\n'
make -C "$SOURCE_DIR/libfont" install

[ -f "$PORTLIBS/include/tiny3d.h" ] || fail "tiny3d.h nao foi instalado em $PORTLIBS/include"
[ -f "$PORTLIBS/lib/libtiny3d.a" ] || fail "libtiny3d.a nao foi instalada em $PORTLIBS/lib"
[ -f "$PORTLIBS/include/libfont.h" ] || fail "libfont.h nao foi instalado em $PORTLIBS/include"
[ -f "$PORTLIBS/lib/libfont.a" ] || fail "libfont.a nao foi instalada em $PORTLIBS/lib"

printf 'OK: Tiny3D e libfont instalados em %s.\n' "$PORTLIBS"
