#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
CC=${CC:-cc}
command -v "$CC" >/dev/null 2>&1 || { echo 'ERRO: compilador host não encontrado.' >&2; exit 1; }
"$CC" -D_DEFAULT_SOURCE -std=c11 -Wall -Wextra -Werror -pedantic \
  -fsyntax-only -I"$ROOT/tests/ps3_stubs" -I"$ROOT/include" \
  "$ROOT/app/source/main.c"
printf 'OK: sintaxe do entry point validada com stubs PSL1GHT.\n'
