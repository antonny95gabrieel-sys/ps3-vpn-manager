# Integração futura com o renderer do PS3

O núcleo da interface agora produz `ui_draw_command_t`. O renderer deve iterar sobre os comandos e implementar:

- `UI_DRAW_CLEAR`: limpar o framebuffer.
- `UI_DRAW_RECT`: desenhar retângulo preenchido.
- `UI_DRAW_TEXT`: desenhar texto usando uma fonte bitmap.
- `UI_DRAW_LINE`: desenhar linha horizontal/vertical.

A biblioteca Tiny3D para PSL1GHT documenta suporte a gráficos 2D/3D e uma biblioteca de fontes (`libfont`). A API concreta e as assinaturas devem ser verificadas nos headers e exemplos da versão instalada antes da implementação do adaptador. Referência: https://github.com/wargio/tiny3D

O aplicativo PSL1GHT também precisa inicializar vídeo/RSX, ler o controle, registrar a saída correta para o XMB e fechar recursos ao sair. O SDK PSL1GHT informa que aplicações típicas geram ELF e SELF e que alguns exemplos fornecem alvo `make pkg`; isso depende da toolchain instalada. Referência: https://github.com/ps3dev/PSL1GHT
