#ifndef UI_VIEW_H
#define UI_VIEW_H

#include <stddef.h>
#include "ui_model.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    UI_DRAW_CLEAR = 0,
    UI_DRAW_RECT,
    UI_DRAW_TEXT,
    UI_DRAW_LINE
} ui_draw_kind_t;

typedef struct {
    ui_draw_kind_t kind;
    float x, y, w, h;
    unsigned int color_rgba;
    int centered;
    char text[80];
} ui_draw_command_t;

typedef struct {
    float width;
    float height;
} ui_viewport_t;

/* Gera comandos de desenho independentes de Tiny3D/RSX.
 * Retorna a quantidade total necessária; grava até capacity comandos.
 */
size_t ui_view_build(const ui_model_t *model, ui_viewport_t viewport,
                     ui_draw_command_t *out, size_t capacity);

#ifdef __cplusplus
}
#endif
#endif
