# Referências reproduzíveis do CI — versão 1.6

O workflow manual aceita duas referências independentes:

- `ps3dev_ref`: branch, tag ou SHA do repositório `ps3dev` (padrão `main`).
- `tiny3d_ref`: branch, tag ou SHA do repositório `tiny3D` (padrão `master`).

O workflow inicializa cada clone, busca a referência pedida e faz checkout detached de `FETCH_HEAD`. Em seguida grava `git rev-parse HEAD` em arquivos de evidência. Para reproduzir uma compilação, use os SHAs completos registrados, não os nomes mutáveis das branches.

O teste local `tests/test_workflow_contract.sh` apenas verifica que esses mecanismos continuam presentes no YAML. Não interpreta YAML, não acessa GitHub e não executa a compilação.

A estrutura segue o fluxo de ambiente descrito pelo projeto ps3dev e mantém o Tiny3D restrito às bibliotecas `lib` e `libfont`, evitando compilar os samples opcionais.
