#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
PAD="$ROOT/tests/ps3_stubs/io/pad.h"
grep -Fq 'u16 button[64];' "$PAD"
grep -Fq 'unsigned int BTN_UP : 1;' "$PAD"
grep -Fq 'unsigned int BTN_CROSS : 1;' "$PAD"
grep -Fq 'u8 status[MAX_PADS];' "$PAD"
grep -Fq 's32 ioPadGetData(u32 port, padData *data);' "$PAD"
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror -pedantic \
  -I"$ROOT/tests/ps3_stubs" -I"$ROOT/include" \
  "$ROOT/src/ps3_pad_adapter.c" "$ROOT/src/ui_runtime.c" \
  "$ROOT/src/ui_model.c" "$ROOT/src/vpn_state.c" \
  "$ROOT/tests/test_ps3_pad_adapter.c" -o "${TMPDIR:-/tmp}/ps3-vpn-pad-api-test-$$"
"${TMPDIR:-/tmp}/ps3-vpn-pad-api-test-$$"
rm -f "${TMPDIR:-/tmp}/ps3-vpn-pad-api-test-$$"
printf 'OK: stub estrutural da libpad e adaptador conferidos.\n'
