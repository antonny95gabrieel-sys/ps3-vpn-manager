# Viabilidade da VPN global

O objetivo do projeto é encaminhar o tráfego de todo o GameOS pelo túnel WireGuard, não apenas o tráfego gerado pelo processo da homebrew.

Um aplicativo GameOS comum não recebe automaticamente controle sobre a rota padrão, DNS e firewall de todo o sistema. A existência de sockets UDP ou de uma implementação WireGuard em espaço de usuário não demonstra que seja possível redirecionar o tráfego de outros processos.

Antes de implementar qualquer alteração de baixo nível, precisamos identificar uma interface suportada e compatível com a versão exata do HEN/HFW. Não aplicar patches LV2, alterar rotas ou instalar módulos desconhecidos como tentativa exploratória: uma falha pode travar o console ou comprometer a rede.

## Critérios de aceitação
1. Handshake WireGuard autenticado.
2. Tráfego originado por pelo menos dois aplicativos diferentes do console observado pelo túnel.
3. Endereço IP público de saída correspondente ao servidor VPN.
4. DNS encaminhado pelo túnel, sem consulta fora dele.
5. Ao interromper o túnel, o tráfego não deve escapar em claro (fail-closed).
6. Desconexão, reconexão e reinicialização não podem deixar rotas/DNS quebrados.

Se não houver método seguro de integração global no HEN, a alternativa tecnicamente confiável será uma VPN no roteador ou gateway de rede. Nesse cenário, a homebrew pode monitorar/administrar o estado apenas se existir uma interface documentada para isso; não deve fingir controlar a VPN do roteador.
