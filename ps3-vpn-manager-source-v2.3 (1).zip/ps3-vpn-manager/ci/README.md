# Compilação remota

## Por que esta etapa existe

O ambiente de execução desta conversa não consegue resolver nomes externos (por exemplo, `github.com`) e não possui `ppu-gcc`, `spu-gcc` ou ferramentas de empacotamento PS3. Portanto, não é possível compilar um SELF/PKG diretamente aqui neste momento.

## Caminho remoto preparado

O workflow `.github/workflows/ps3-toolchain-check.yml` foi preparado para ser executado manualmente em GitHub Actions. Ele tenta construir o ambiente oficial `ps3dev` em um runner Ubuntu e verifica os compiladores PPU/SPU.

O workflow prepara a toolchain, valida os componentes PSL1GHT básicos, compila/instala Tiny3D/libfont como verificação auxiliar e instala a revisão PSL1GHT selecionada. A versão 2.2 adiciona um entry point PSL1GHT e o workflow tenta compilar `app/`, gerar ELF/SELF e executar o alvo `pkg`. A execução do workflow ainda precisa ser confirmada; não há binários reais enquanto essa etapa não concluir.

As revisões dos repositórios ps3dev e Tiny3D são registradas nos artefatos do workflow. Como as branches padrão ainda são clonadas sem SHA fixo, os hashes precisam ser fixados depois de uma execução bem-sucedida para garantir builds reproduzíveis.

## Próxima etapa

1. Executar o workflow e resolver erros de compilação/linkagem PPU.
2. Confirmar ELF, SELF, PKG e manifesto SHA-256.
3. Instalar o PKG no PS3 Super Slim e testar vídeo, controle e encerramento XMB.
4. Só depois avançar para configuração e engine WireGuard; a integração de rede global continua sendo uma pesquisa separada.

Referências oficiais:
- https://github.com/ps3dev/ps3dev
- https://github.com/ps3dev/PSL1GHT


## Seleção de revisões — versão 1.6

Ao iniciar manualmente `PS3 SDK and graphics dependency check`, os inputs `ps3dev_ref` e `tiny3d_ref` aceitam branch, tag ou SHA. Para builds reproduzíveis, informe o SHA completo de cada commit. Os arquivos `ps3dev-revision.txt` e `tiny3d-revision.txt` no artefato registram os commits realmente usados. Os defaults (`main` e `master`) são convenientes, mas podem mudar com o tempo e não substituem SHAs fixos.
