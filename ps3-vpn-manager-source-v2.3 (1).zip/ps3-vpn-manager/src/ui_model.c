#include "ui_model.h"
#include <stddef.h>
#include <string.h>

#define HOME_ITEMS 4u

void ui_model_init(ui_model_t *ui)
{
    if (ui == NULL) return;
    memset(ui, 0, sizeof(*ui));
    ui->screen = UI_SCREEN_HOME;
    ui->vpn_state = VPN_STATE_DISCONNECTED;
    ui->kill_switch_enabled = 0;
    ui->global_tunnel_verified = 0;
    (void)strncpy(ui->server_label, "Nenhum servidor", sizeof(ui->server_label) - 1u);
    (void)strncpy(ui->public_ip, "Nao verificado", sizeof(ui->public_ip) - 1u);
}

ui_action_t ui_model_handle_button(ui_model_t *ui, ui_button_t button)
{
    if (ui == NULL) return UI_ACTION_NONE;

    if (ui->screen != UI_SCREEN_HOME) {
        if (button == UI_BUTTON_CIRCLE) {
            ui->screen = UI_SCREEN_HOME;
            ui->selection = 0u;
            return UI_ACTION_BACK;
        }
        return UI_ACTION_NONE;
    }

    if (button == UI_BUTTON_UP) {
        ui->selection = (ui->selection == 0u) ? HOME_ITEMS - 1u : ui->selection - 1u;
        return UI_ACTION_NONE;
    }
    if (button == UI_BUTTON_DOWN) {
        ui->selection = (ui->selection + 1u) % HOME_ITEMS;
        return UI_ACTION_NONE;
    }
    if (button != UI_BUTTON_CROSS) return UI_ACTION_NONE;

    switch (ui->selection) {
    case 0u:
        return (ui->vpn_state == VPN_STATE_CONNECTED ||
                ui->vpn_state == VPN_STATE_CONNECTING)
                   ? UI_ACTION_NONE : UI_ACTION_CONNECT;
    case 1u:
        return (ui->vpn_state == VPN_STATE_CONNECTED ||
                ui->vpn_state == VPN_STATE_CONNECTING ||
                ui->vpn_state == VPN_STATE_ERROR)
                   ? UI_ACTION_DISCONNECT : UI_ACTION_NONE;
    case 2u:
        ui->screen = UI_SCREEN_CONFIGURATION;
        return UI_ACTION_OPEN_CONFIGURATION;
    case 3u:
        ui->screen = UI_SCREEN_DIAGNOSTICS;
        return UI_ACTION_OPEN_DIAGNOSTICS;
    default:
        return UI_ACTION_NONE;
    }
}

const char *ui_model_screen_name(ui_screen_t screen)
{
    switch (screen) {
    case UI_SCREEN_HOME: return "Inicio";
    case UI_SCREEN_CONFIGURATION: return "Configuracao";
    case UI_SCREEN_DIAGNOSTICS: return "Diagnostico";
    default: return "Tela desconhecida";
    }
}

const char *ui_model_connection_summary(const ui_model_t *ui)
{
    if (ui == NULL) return "Estado indisponivel";
    if (ui->vpn_state == VPN_STATE_CONNECTED && !ui->global_tunnel_verified)
        return "Tunel do aplicativo; protecao global nao verificada";
    if (ui->vpn_state == VPN_STATE_CONNECTED && ui->global_tunnel_verified)
        return "Tunel global verificado";
    return vpn_state_name(ui->vpn_state);
}
