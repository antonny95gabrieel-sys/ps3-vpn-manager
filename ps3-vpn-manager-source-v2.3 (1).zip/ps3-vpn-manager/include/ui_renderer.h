#ifndef UI_RENDERER_H
#define UI_RENDERER_H

#include <stddef.h>
#include "ui_view.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    void (*clear)(void *context, unsigned int color_rgba,
                  float width, float height);
    void (*rectangle)(void *context, float x, float y, float width,
                      float height, unsigned int color_rgba);
    void (*text)(void *context, float x, float y, float width, float height,
                 unsigned int color_rgba, int centered, const char *value);
    void (*line)(void *context, float x, float y, float width, float height,
                 unsigned int color_rgba);
    void *context;
} ui_renderer_backend_t;

typedef enum {
    UI_RENDER_OK = 0,
    UI_RENDER_INVALID_ARGUMENT = -1,
    UI_RENDER_MISSING_CALLBACK = -2,
    UI_RENDER_UNKNOWN_COMMAND = -3,
    UI_RENDER_INVALID_GEOMETRY = -4,
    UI_RENDER_INVALID_COMMAND_DATA = -5
} ui_render_result_t;

/* Valida o quadro inteiro antes de encaminhar qualquer comando ao backend.
 * O backend Tiny3D/RSX ainda deverá ser implementado separadamente.
 * Retorna UI_RENDER_OK ou o primeiro erro encontrado.
 */
ui_render_result_t ui_renderer_submit(const ui_renderer_backend_t *backend,
                                      const ui_draw_command_t *commands,
                                      size_t count);

#ifdef __cplusplus
}
#endif
#endif
