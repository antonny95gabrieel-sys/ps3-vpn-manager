# Interface — versão 0.5

## O que esta versão entrega

A versão 0.5 adiciona `ui_view.h` e `ui_view.c`, uma camada de layout que converte o estado da aplicação em uma lista de comandos de desenho (limpar tela, retângulo, texto e linha). Ela define dimensões relativas à resolução, cores, cartões de estado e os conteúdos das telas Início, Configuração e Diagnóstico.

A camada é independente de Tiny3D/RSX. Um adaptador de renderização ainda precisa converter cada comando para as chamadas reais da biblioteca gráfica escolhida.

## O que foi testado

- Geração de comandos para viewport 1280x720.
- Título e estado inicial desconectado.
- Mensagem explícita de túnel global não verificado.
- Rejeição de viewports menores que 320x240.
- Compilação C11 com `-Wall -Wextra -Werror -pedantic`.

## O que NÃO foi entregue

- Não é ainda uma interface gráfica executável no PS3.
- Não inicializa RSX nem usa Tiny3D.
- Não lê o DualShock 3 no hardware.
- Não gera ELF, SELF ou PKG.
- Não implementa WireGuard ou VPN global.

## Próxima tarefa de integração

Criar um adaptador PSL1GHT/Tiny3D com base nos headers e samples da versão exata das bibliotecas instaladas. Não inventar nomes de funções: confirmar as assinaturas no SDK antes de ligar `ui_draw_command_t` ao renderer.
