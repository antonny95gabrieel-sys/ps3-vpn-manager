# Adaptador de controle PSL1GHT — versão 0.8

`src/ps3_pad_adapter.c` converte os seis botões usados pela interface (direções, X e O) da estrutura `padData` para as máscaras normalizadas consumidas por `ui_runtime_update()`.

A separação é intencional: o aplicativo PSL1GHT continuará responsável por chamar `ioPadInit()`, `ioPadGetInfo()` e `ioPadGetData()`. O adaptador não faz polling, não inicializa libpad e não presume que exista um controle conectado.

## Teste disponível

`make -f Makefile.host test` compila o adaptador contra um stub mínimo de `io/pad.h`. Isso verifica a conversão de campos e máscaras no host, mas **não substitui** uma compilação contra os headers reais do PSL1GHT nem um teste com DualShock 3 no console.

Os nomes `BTN_UP`, `BTN_DOWN`, `BTN_LEFT`, `BTN_RIGHT`, `BTN_CROSS` e `BTN_CIRCLE` aparecem em exemplos públicos de aplicações PSL1GHT. A confirmação definitiva será feita pelo build remoto contra a versão de SDK escolhida.

Referências:
- https://github.com/ps3dev/PSL1GHT
- https://github.com/bucanero/apollo-ps3/blob/master/source/menu_main.c
- https://github.com/wargio/tiny3D
