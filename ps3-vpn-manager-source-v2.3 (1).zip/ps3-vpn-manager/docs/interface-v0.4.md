# Interface — versão 0.4

## Escopo desta entrega

Esta versão implementa o **modelo de navegação** da interface, independente do renderizador gráfico. Ela ainda não é uma aplicação PSL1GHT, não desenha pixels na RSX, não lê o controle DualShock 3 no hardware e não gera SELF/PKG.

## Organização visual planejada

- Cabeçalho: `PS3 VPN MANAGER` e versão.
- Cartão de estado: Desconectado / Configurado / Conectando / Conectado / Desconectando / Erro.
- Linha de servidor: nome do peer selecionado.
- Linha de endereço: IP público somente após consulta real e bem-sucedida.
- Menu: Conectar, Desconectar, Configuração, Diagnóstico.
- Rodapé: X selecionar · O voltar.

## Controles mapeados no modelo

- Cima/Baixo: mudar seleção.
- X: executar a opção selecionada.
- O: voltar à tela anterior.

## Regras de segurança da interface

1. A interface não pode marcar `Conectado` por mera mudança visual: precisa receber resultado real do motor VPN.
2. O IP público começa como `Não verificado` e só pode ser atualizado por uma consulta de rede real.
3. A frase `Tunel global verificado` só aparece quando testes de tráfego fora do processo da homebrew confirmarem a rota global.
4. `Kill Switch` não deve ser apresentado como ativo até existir um bloqueio de tráfego testado quando o túnel cai.
5. Nenhuma chave privada deve aparecer na interface, em logs ou em capturas de diagnóstico.

## Limite XMB

“Integrada ao XMB” significa, nesta fase, um aplicativo lançado pelo ícone na categoria Jogo do XMB. Alterar a interface nativa do XMB ou instalar um plugin residente são projetos separados, mais invasivos e não necessários para a primeira versão.
