#include "ui_renderer.h"
#include <math.h>
#include <string.h>

static ui_render_result_t validate_command(const ui_renderer_backend_t *backend,
                                           const ui_draw_command_t *command)
{
    if (!isfinite(command->x) || !isfinite(command->y) ||
        !isfinite(command->w) || !isfinite(command->h))
        return UI_RENDER_INVALID_GEOMETRY;

    switch (command->kind) {
    case UI_DRAW_CLEAR:
        if (command->w <= 0.0f || command->h <= 0.0f)
            return UI_RENDER_INVALID_GEOMETRY;
        return backend->clear != 0 ? UI_RENDER_OK : UI_RENDER_MISSING_CALLBACK;
    case UI_DRAW_RECT:
        if (command->w < 0.0f || command->h < 0.0f)
            return UI_RENDER_INVALID_GEOMETRY;
        return backend->rectangle != 0 ? UI_RENDER_OK : UI_RENDER_MISSING_CALLBACK;
    case UI_DRAW_TEXT:
        if (command->w < 0.0f || command->h < 0.0f ||
            memchr(command->text, '\0', sizeof(command->text)) == 0)
            return UI_RENDER_INVALID_COMMAND_DATA;
        return backend->text != 0 ? UI_RENDER_OK : UI_RENDER_MISSING_CALLBACK;
    case UI_DRAW_LINE:
        if (command->w < 0.0f || command->h < 0.0f)
            return UI_RENDER_INVALID_GEOMETRY;
        return backend->line != 0 ? UI_RENDER_OK : UI_RENDER_MISSING_CALLBACK;
    default:
        return UI_RENDER_UNKNOWN_COMMAND;
    }
}

static void dispatch_command(const ui_renderer_backend_t *backend,
                             const ui_draw_command_t *command)
{
    switch (command->kind) {
    case UI_DRAW_CLEAR:
        backend->clear(backend->context, command->color_rgba,
                       command->w, command->h);
        break;
    case UI_DRAW_RECT:
        backend->rectangle(backend->context, command->x, command->y,
                           command->w, command->h, command->color_rgba);
        break;
    case UI_DRAW_TEXT:
        backend->text(backend->context, command->x, command->y,
                      command->w, command->h, command->color_rgba,
                      command->centered, command->text);
        break;
    case UI_DRAW_LINE:
        backend->line(backend->context, command->x, command->y,
                      command->w, command->h, command->color_rgba);
        break;
    default:
        /* A lista já foi validada integralmente antes do despacho. */
        break;
    }
}

ui_render_result_t ui_renderer_submit(const ui_renderer_backend_t *backend,
                                      const ui_draw_command_t *commands,
                                      size_t count)
{
    size_t i;

    if (backend == 0 || (commands == 0 && count != 0u))
        return UI_RENDER_INVALID_ARGUMENT;

    /* Primeira passagem: nenhuma operação gráfica ocorre antes da validação
       integral do quadro. Isso evita quadros parcialmente desenhados. */
    for (i = 0; i < count; ++i) {
        ui_render_result_t result = validate_command(backend, &commands[i]);
        if (result != UI_RENDER_OK) return result;
    }

    /* Segunda passagem: todos os comandos e callbacks estão disponíveis. */
    for (i = 0; i < count; ++i)
        dispatch_command(backend, &commands[i]);

    return UI_RENDER_OK;
}
