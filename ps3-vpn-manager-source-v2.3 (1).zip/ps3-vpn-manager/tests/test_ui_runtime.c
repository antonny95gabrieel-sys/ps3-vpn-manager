#include <assert.h>
#include <stdio.h>
#include "ui_runtime.h"

int main(void)
{
    ui_model_t model;
    ui_runtime_t runtime;

    ui_model_init(&model);
    ui_runtime_init(&runtime);

    assert(ui_runtime_update(&runtime, &model, UI_KEY_DOWN) == UI_ACTION_NONE);
    assert(model.selection == 1u);
    /* Segurar o direcional não deve repetir a navegação. */
    assert(ui_runtime_update(&runtime, &model, UI_KEY_DOWN) == UI_ACTION_NONE);
    assert(model.selection == 1u);
    /* Soltar e pressionar novamente deve gerar nova ação. */
    assert(ui_runtime_update(&runtime, &model, 0u) == UI_ACTION_NONE);
    assert(ui_runtime_update(&runtime, &model, UI_KEY_DOWN) == UI_ACTION_NONE);
    assert(model.selection == 2u);
    assert(ui_runtime_update(&runtime, &model, 0u) == UI_ACTION_NONE);
    assert(ui_runtime_update(&runtime, &model, UI_KEY_CROSS) == UI_ACTION_OPEN_CONFIGURATION);
    assert(model.screen == UI_SCREEN_CONFIGURATION);
    assert(ui_runtime_update(&runtime, &model, 0u) == UI_ACTION_NONE);
    assert(ui_runtime_update(&runtime, &model, UI_KEY_CIRCLE) == UI_ACTION_BACK);
    assert(model.screen == UI_SCREEN_HOME);
    assert(ui_runtime_update(NULL, &model, UI_KEY_UP) == UI_ACTION_NONE);
    assert(ui_runtime_update(&runtime, NULL, UI_KEY_UP) == UI_ACTION_NONE);

    puts("OK: entrada por borda, repeticao e navegacao verificadas");
    return 0;
}
