#ifndef TEST_RSX_H
#define TEST_RSX_H
#include <ppu-types.h>
typedef struct gcmContextData { int unused; } gcmContextData;
#define GCM_FLIP_VSYNC 2
s32 rsxInit(gcmContextData **context, u32 cmd_size, u32 io_size, const void *io_address);
void *rsxMemalign(u32 alignment, u32 size);
s32 rsxAddressToOffset(const void *ptr, u32 *offset);
void gcmSetFlipMode(u32 mode);
s32 gcmSetDisplayBuffer(u32 id, u32 offset, u32 pitch, u32 width, u32 height);
void gcmResetFlipStatus(void);
s32 gcmGetFlipStatus(void);
s32 gcmSetFlip(gcmContextData *context, u32 buffer);
void rsxFlushBuffer(gcmContextData *context);
void gcmSetWaitFlip(gcmContextData *context);
#endif
