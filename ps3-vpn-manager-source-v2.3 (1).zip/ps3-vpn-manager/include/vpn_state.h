#ifndef VPN_STATE_H
#define VPN_STATE_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    VPN_STATE_DISCONNECTED = 0,
    VPN_STATE_CONFIGURED,
    VPN_STATE_CONNECTING,
    VPN_STATE_CONNECTED,
    VPN_STATE_DISCONNECTING,
    VPN_STATE_ERROR
} vpn_state_t;

typedef enum {
    VPN_EVENT_CONFIG_VALID = 0,
    VPN_EVENT_CONNECT_REQUEST,
    VPN_EVENT_HANDSHAKE_OK,
    VPN_EVENT_HANDSHAKE_FAILED,
    VPN_EVENT_DISCONNECT_REQUEST,
    VPN_EVENT_TUNNEL_CLOSED,
    VPN_EVENT_RESET
} vpn_event_t;

/* Retorna o próximo estado; eventos inválidos preservam o estado atual. */
vpn_state_t vpn_state_transition(vpn_state_t current, vpn_event_t event);
const char *vpn_state_name(vpn_state_t state);

#ifdef __cplusplus
}
#endif
#endif
