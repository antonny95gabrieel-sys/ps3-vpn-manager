# Plano de testes no PS3 — quando houver PKG compilado

Este documento define o que será verificado no PS3 Super Slim. Nenhum teste foi executado no console ainda.

## Antes de instalar
- Confirmar o modelo e a versão do firmware exibida em Informações do sistema.
- Confirmar a identificação exata do HEN em HFW Tools.
- Manter o PKG de teste identificado como versão de desenvolvimento.
- Não substituir arquivos de sistema nem instalar módulos residentes nesta fase.

## Teste A — instalação e inicialização
1. Copiar o PKG para a raiz de um USB FAT32.
2. No XMB, abrir Jogos > Install Package Files e selecionar o pacote.
3. Confirmar que o ícone aparece na categoria Jogos.
4. Abrir o aplicativo e verificar se a tela inicial aparece sem congelamento.
5. Sair pelo procedimento previsto e confirmar retorno ao XMB.

## Teste B — controles e interface
- D-pad para cima/baixo move a seleção uma posição por pressão.
- Manter uma tecla pressionada não deve disparar ações repetidas involuntariamente.
- X confirma; O retorna.
- Alternar entre Home, Configuration e Diagnostics.
- Verificar legibilidade em 720p e 1080p, se disponíveis.

## Teste C — segurança de estado
- Sem backend real, a tela deve permanecer Desconectado/Não verificado.
- Não deve mostrar IP público como validado sem consulta real.
- Não deve declarar Kill Switch ativo enquanto não houver bloqueio de tráfego testado.

## Teste D — VPN (somente depois do backend)
- Usar primeiro uma configuração de teste sem credenciais compartilhadas.
- Confirmar handshake WireGuard e contadores de tráfego.
- Confirmar IP público antes/depois por um método independente.
- Testar queda do endpoint e verificar comportamento fail-closed.
- Verificar separadamente navegador, jogo/aplicativo e serviços do sistema.
- Só declarar cobertura global depois de provar que o tráfego de cada classe passa pelo túnel e que não há vazamento durante queda/reconexão.

## Registro do usuário
Para cada teste, registrar: versão do PKG, firmware, versão HEN, resultado, mensagem de erro e foto da tela quando possível. Nunca fotografar ou enviar a chave privada WireGuard.
