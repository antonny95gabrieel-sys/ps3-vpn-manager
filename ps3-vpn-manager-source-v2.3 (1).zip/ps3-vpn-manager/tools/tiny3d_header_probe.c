/* Compile-only probe: verifies that the installed Tiny3D public headers can be
 * consumed by the selected PPU compiler. It does not initialize RSX or draw. */
#include <tiny3d.h>
#include <libfont.h>

int ps3vm_tiny3d_headers_available(void)
{
    return 1;
}
