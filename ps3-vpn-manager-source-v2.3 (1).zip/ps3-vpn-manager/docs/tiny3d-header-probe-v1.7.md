# Verificação de headers Tiny3D — v1.7

A versão 1.7 adiciona um probe de compilação (`tools/tiny3d_header_probe.c`) que inclui os headers públicos `tiny3d.h` e `libfont.h`. O script `tools/check-tiny3d-headers.sh` chama `ppu-gcc -fsyntax-only` com os diretórios de include do Tiny3D e PSL1GHT.

O workflow de validação do SDK executa esse probe depois de instalar Tiny3D/libfont. Assim, uma execução remota bem-sucedida demonstrará que o compilador PPU consegue analisar uma unidade de tradução que inclui os dois headers instalados.

## O que isso comprova

- `ppu-gcc` está disponível;
- os dois headers existem;
- o compilador aceita suas declarações e dependências de inclusão no contexto fornecido.

## O que isso NÃO comprova

- que símbolos Tiny3D específicos foram chamados corretamente;
- que a aplicação foi vinculada;
- que existe um `main` PSL1GHT;
- que RSX/framebuffer inicializa;
- que há ELF, SELF ou PKG;
- que a imagem aparece ou funciona no PS3 real.

O probe é deliberadamente pequeno: antes de implementar o backend gráfico, precisamos validar a compatibilidade real dos headers com a toolchain que o workflow instalar.
