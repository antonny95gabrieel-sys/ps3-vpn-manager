#ifndef UI_MODEL_H
#define UI_MODEL_H

#include "vpn_state.h"

typedef enum {
    UI_SCREEN_HOME = 0,
    UI_SCREEN_CONFIGURATION,
    UI_SCREEN_DIAGNOSTICS
} ui_screen_t;

typedef enum {
    UI_ACTION_NONE = 0,
    UI_ACTION_CONNECT,
    UI_ACTION_DISCONNECT,
    UI_ACTION_OPEN_CONFIGURATION,
    UI_ACTION_OPEN_DIAGNOSTICS,
    UI_ACTION_BACK
} ui_action_t;

typedef enum {
    UI_BUTTON_UP = 0,
    UI_BUTTON_DOWN,
    UI_BUTTON_CROSS,
    UI_BUTTON_CIRCLE,
    UI_BUTTON_LEFT,
    UI_BUTTON_RIGHT
} ui_button_t;

typedef struct {
    ui_screen_t screen;
    unsigned int selection;
    vpn_state_t vpn_state;
    int config_present;
    int kill_switch_enabled;
    int global_tunnel_verified;
    char server_label[48];
    char public_ip[48];
} ui_model_t;

void ui_model_init(ui_model_t *ui);
ui_action_t ui_model_handle_button(ui_model_t *ui, ui_button_t button);
const char *ui_model_screen_name(ui_screen_t screen);
const char *ui_model_connection_summary(const ui_model_t *ui);

#endif
