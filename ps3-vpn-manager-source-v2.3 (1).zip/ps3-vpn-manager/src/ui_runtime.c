#include "ui_runtime.h"
#include <stddef.h>

void ui_runtime_init(ui_runtime_t *runtime)
{
    if (runtime != NULL) runtime->previous_keys = 0u;
}

ui_action_t ui_runtime_update(ui_runtime_t *runtime, ui_model_t *model,
                              uint32_t current_keys)
{
    uint32_t pressed;
    ui_button_t button;

    if (runtime == NULL || model == NULL) return UI_ACTION_NONE;
    pressed = current_keys & ~runtime->previous_keys;
    runtime->previous_keys = current_keys;

    /* Uma ação por atualização. Botões de confirmação/retorno têm prioridade. */
    if ((pressed & UI_KEY_CROSS) != 0u) button = UI_BUTTON_CROSS;
    else if ((pressed & UI_KEY_CIRCLE) != 0u) button = UI_BUTTON_CIRCLE;
    else if ((pressed & UI_KEY_UP) != 0u) button = UI_BUTTON_UP;
    else if ((pressed & UI_KEY_DOWN) != 0u) button = UI_BUTTON_DOWN;
    else if ((pressed & UI_KEY_LEFT) != 0u) button = UI_BUTTON_LEFT;
    else if ((pressed & UI_KEY_RIGHT) != 0u) button = UI_BUTTON_RIGHT;
    else return UI_ACTION_NONE;

    return ui_model_handle_button(model, button);
}
