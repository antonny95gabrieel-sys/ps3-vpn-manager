#include <assert.h>
#include <stdio.h>
#include "vpn_state.h"

int main(void)
{
    vpn_state_t s = VPN_STATE_DISCONNECTED;
    s = vpn_state_transition(s, VPN_EVENT_CONFIG_VALID);
    assert(s == VPN_STATE_CONFIGURED);
    s = vpn_state_transition(s, VPN_EVENT_CONNECT_REQUEST);
    assert(s == VPN_STATE_CONNECTING);
    s = vpn_state_transition(s, VPN_EVENT_HANDSHAKE_OK);
    assert(s == VPN_STATE_CONNECTED);
    s = vpn_state_transition(s, VPN_EVENT_DISCONNECT_REQUEST);
    assert(s == VPN_STATE_DISCONNECTING);
    s = vpn_state_transition(s, VPN_EVENT_TUNNEL_CLOSED);
    assert(s == VPN_STATE_CONFIGURED);
    puts("OK: transições básicas verificadas");
    return 0;
}
