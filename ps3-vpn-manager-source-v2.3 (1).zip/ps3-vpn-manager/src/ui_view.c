#include "ui_view.h"
#include <stdio.h>
#include <string.h>

#define C_BG       0x101B2BFFu
#define C_PANEL    0x20334DFFu
#define C_PANEL2   0x17283EFFu
#define C_WHITE    0xF4F7FCFFu
#define C_MUTED    0xA8B9D0FFu
#define C_BLUE     0x397CC0FFu
#define C_GREEN    0x42B883FFu
#define C_AMBER    0xE5AE45FFu
#define C_RED      0xD65C65FFu

static void push(ui_draw_command_t *out, size_t cap, size_t *n,
                 ui_draw_kind_t kind, float x, float y, float w, float h,
                 unsigned int color, int centered, const char *text)
{
    if (out != NULL && *n < cap) {
        ui_draw_command_t *c = &out[*n];
        memset(c, 0, sizeof(*c));
        c->kind = kind; c->x = x; c->y = y; c->w = w; c->h = h;
        c->color_rgba = color; c->centered = centered;
        if (text != NULL) (void)snprintf(c->text, sizeof(c->text), "%s", text);
    }
    ++(*n);
}

static unsigned int state_color(vpn_state_t state)
{
    switch (state) {
    case VPN_STATE_CONNECTED: return C_GREEN;
    case VPN_STATE_CONNECTING:
    case VPN_STATE_DISCONNECTING: return C_AMBER;
    case VPN_STATE_ERROR: return C_RED;
    default: return C_MUTED;
    }
}

size_t ui_view_build(const ui_model_t *m, ui_viewport_t vp,
                     ui_draw_command_t *out, size_t capacity)
{
    size_t n = 0;
    float margin, content_w, x, y, row_h;
    char line[80];
    const char *screen;
    if (m == NULL || vp.width < 320.0f || vp.height < 240.0f) return 0;

    margin = vp.width * 0.055f;
    content_w = vp.width - 2.0f * margin;
    x = margin;
    push(out, capacity, &n, UI_DRAW_CLEAR, 0, 0, vp.width, vp.height, C_BG, 0, NULL);
    push(out, capacity, &n, UI_DRAW_TEXT, x, vp.height * 0.055f, content_w, 28,
         C_WHITE, 0, "PS3 VPN MANAGER");
    push(out, capacity, &n, UI_DRAW_TEXT, x + content_w - 190, vp.height * 0.06f,
         190, 22, C_MUTED, 1, "APP 2.2");
    push(out, capacity, &n, UI_DRAW_LINE, x, vp.height * 0.12f, content_w, 2,
         C_PANEL, 0, NULL);

    screen = ui_model_screen_name(m->screen);
    push(out, capacity, &n, UI_DRAW_TEXT, x, vp.height * 0.155f, content_w, 24,
         C_MUTED, 0, screen);

    if (m->screen == UI_SCREEN_HOME) {
        y = vp.height * 0.22f;
        push(out, capacity, &n, UI_DRAW_RECT, x, y, content_w, vp.height * 0.24f,
             C_PANEL, 0, NULL);
        push(out, capacity, &n, UI_DRAW_TEXT, x + 22, y + 18, content_w - 44, 22,
             C_MUTED, 0, "ESTADO DA CONEXAO");
        push(out, capacity, &n, UI_DRAW_TEXT, x + 22, y + 55, content_w - 44, 42,
             state_color(m->vpn_state), 0, vpn_state_name(m->vpn_state));
        push(out, capacity, &n, UI_DRAW_TEXT, x + 22, y + 105, content_w - 44, 20,
             C_MUTED, 0, ui_model_connection_summary(m));

        y = vp.height * 0.50f;
        row_h = vp.height * 0.075f;
        {
            static const char *items[] = {"CONECTAR", "DESCONECTAR", "CONFIGURACAO", "DIAGNOSTICO"};
            unsigned int i;
            for (i = 0; i < 4; ++i) {
                unsigned int color = (m->selection == i) ? C_BLUE : C_PANEL2;
                push(out, capacity, &n, UI_DRAW_RECT, x, y + i * (row_h + 8),
                     content_w, row_h, color, 0, NULL);
                push(out, capacity, &n, UI_DRAW_TEXT, x + 18, y + i * (row_h + 8) + 10,
                     content_w - 36, row_h - 12, C_WHITE, 0, items[i]);
            }
        }
        (void)snprintf(line, sizeof(line), "Servidor: %s", m->server_label);
        push(out, capacity, &n, UI_DRAW_TEXT, x, vp.height * 0.87f, content_w, 20,
             C_MUTED, 0, line);
        push(out, capacity, &n, UI_DRAW_TEXT, x, vp.height * 0.93f, content_w, 18,
             C_MUTED, 0, "X Selecionar    O Voltar");
    } else if (m->screen == UI_SCREEN_CONFIGURATION) {
        y = vp.height * 0.25f;
        push(out, capacity, &n, UI_DRAW_RECT, x, y, content_w, vp.height * 0.48f,
             C_PANEL, 0, NULL);
        push(out, capacity, &n, UI_DRAW_TEXT, x + 22, y + 22, content_w - 44, 24,
             C_WHITE, 0, "CONFIGURACAO WIREGUARD");
        push(out, capacity, &n, UI_DRAW_TEXT, x + 22, y + 70, content_w - 44, 22,
             C_MUTED, 0, m->config_present ? "Arquivo de configuracao detectado" : "Nenhum arquivo configurado");
        push(out, capacity, &n, UI_DRAW_TEXT, x + 22, y + 112, content_w - 44, 22,
             C_MUTED, 0, "Chave privada: nunca exibida");
        push(out, capacity, &n, UI_DRAW_TEXT, x + 22, y + 154, content_w - 44, 22,
             C_MUTED, 0, "O parser WireGuard ainda nao foi implementado.");
        push(out, capacity, &n, UI_DRAW_TEXT, x, vp.height * 0.93f, content_w, 18,
             C_MUTED, 0, "O Voltar");
    } else {
        y = vp.height * 0.25f;
        push(out, capacity, &n, UI_DRAW_RECT, x, y, content_w, vp.height * 0.52f,
             C_PANEL, 0, NULL);
        push(out, capacity, &n, UI_DRAW_TEXT, x + 22, y + 22, content_w - 44, 24,
             C_WHITE, 0, "DIAGNOSTICO");
        (void)snprintf(line, sizeof(line), "VPN: %s", vpn_state_name(m->vpn_state));
        push(out, capacity, &n, UI_DRAW_TEXT, x + 22, y + 68, content_w - 44, 22,
             state_color(m->vpn_state), 0, line);
        (void)snprintf(line, sizeof(line), "IP publico: %s", m->public_ip);
        push(out, capacity, &n, UI_DRAW_TEXT, x + 22, y + 108, content_w - 44, 22,
             C_MUTED, 0, line);
        push(out, capacity, &n, UI_DRAW_TEXT, x + 22, y + 148, content_w - 44, 22,
             C_MUTED, 0, m->kill_switch_enabled ? "Kill Switch: configurado (nao validado)" : "Kill Switch: desativado");
        push(out, capacity, &n, UI_DRAW_TEXT, x + 22, y + 188, content_w - 44, 22,
             C_AMBER, 0, m->global_tunnel_verified ? "Verificacao global sinalizada pelo backend" : "Tunel global: NAO VERIFICADO");
        push(out, capacity, &n, UI_DRAW_TEXT, x, vp.height * 0.93f, content_w, 18,
             C_MUTED, 0, "O Voltar");
    }
    return n;
}
