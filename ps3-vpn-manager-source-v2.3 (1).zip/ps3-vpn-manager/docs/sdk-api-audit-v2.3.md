# Auditoria de APIs PSL1GHT — versão 2.3

Esta auditoria compara os nomes, tipos e chamadas usados pelo entry point com
os headers do repositório oficial `ps3dev/PSL1GHT` consultados nesta revisão.

## Interfaces conferidas

| Arquivo oficial | Elementos usados | Resultado |
|---|---|---|
| `ppu/include/io/pad.h` | `padInfo`, `padData`, `MAX_PORT_NUM`, `ioPadInit`, `ioPadGetInfo`, `ioPadGetData`, `ioPadEnd` | Nomes e assinaturas conferidos |
| `ppu/include/sysutil/sysutil.h` | `sysutilCallback`, `SYSUTIL_EVENT_SLOT0`, `SYSUTIL_EXIT_GAME`, registro/verificação/remoção de callback | Nomes, valores e assinatura do callback conferidos |
| `ppu/include/sysutil/video.h` | `videoState`, `videoResolution`, `videoConfiguration`, `videoGetState`, `videoGetResolution`, `videoConfigure` | Estruturas e assinaturas conferidas |
| `ppu/include/rsx/rsx.h` e `ppu/include/rsx/gcm_sys.h` | `rsxInit`, `rsxMemalign`, `rsxAddressToOffset`, operações de flip e buffers de exibição | Chamadas conferidas por headers e sample oficial |
| `ppu_rules` | regras `.self` e `.pkg`, `TITLE`, `APPID`, `CONTENTID`, `ICON0`, `PKGFILES` | Fluxo de empacotamento conferido |

Referências de conteúdo consultadas no repositório oficial:

- `io/pad.h`, blob SHA `08e855b6bc12702b491768e6c3d7283b2fc6b01e`
- `sysutil/sysutil.h`, blob SHA `85f1655ada81bc4fc1fd65de4d3e15b3e4120cf5`
- `video.h`, blob SHA `6b22cab753a7b9c0a365d7b1ac03961628007679`
- `rsxutil.cpp`, sample `rsxtest`, blob SHA `712c00179e8777c054648b6010ffb1cc473c6e2a`
- `ppu_rules`, blob SHA `cd34c722fab3a42c32cde80f10fea6ffb866327c`

## Ajuste de testes

O stub local de `io/pad.h` foi ampliado para preservar a union e os campos
`BTN_*` da estrutura `padData` oficial. O teste de conversão agora compila
contra uma representação estrutural mais próxima da API real, em vez de uma
estrutura simplificada com bitfields em posições diferentes.

## Limite da auditoria

A conferência de headers não é uma compilação PPU. O ambiente desta sessão não
possui `ppu-gcc`, linker PPU nem ferramentas `make_self`/`pkg`. Portanto, esta
revisão não comprova link, geração de SELF/PKG, coerência de cache RSX ou
execução no console. A próxima prova decisiva continua sendo executar o
workflow com a toolchain real e depois testar o pacote no PS3.
