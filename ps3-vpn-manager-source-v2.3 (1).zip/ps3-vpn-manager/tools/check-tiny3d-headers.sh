#!/bin/sh
set -eu

fail() { printf 'ERRO: %s\n' "$1" >&2; exit 1; }
: "${PSL1GHT:?Defina PSL1GHT para a raiz do PSL1GHT}"
: "${PS3DEV:?Defina PS3DEV para a raiz do ambiente ps3dev}"
: "${PORTLIBS:=$PS3DEV/portlibs/ppu}"
command -v ppu-gcc >/dev/null 2>&1 || fail "ppu-gcc ausente no PATH"
[ -f "$PORTLIBS/include/tiny3d.h" ] || fail "tiny3d.h ausente"
[ -f "$PORTLIBS/include/libfont.h" ] || fail "libfont.h ausente"
[ -f "tools/tiny3d_header_probe.c" ] || fail "arquivo de probe ausente; execute na raiz do projeto"

printf 'Verificando inclusao dos headers Tiny3D/libfont com PPU GCC...\n'
ppu-gcc -std=gnu11 -fsyntax-only \
  -I"$PORTLIBS/include" \
  -I"$PSL1GHT/ppu/include" \
  tools/tiny3d_header_probe.c
printf 'OK: os headers Tiny3D/libfont foram aceitos pelo compilador PPU.\n'
printf 'NOTA: esta verificacao nao faz link, nao gera ELF/SELF/PKG e nao valida renderizacao.\n'
