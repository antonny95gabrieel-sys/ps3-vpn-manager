#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
WF="$ROOT/.github/workflows/ps3-toolchain-check.yml"
grep -q 'psl1ght_ref:' "$WF"
grep -q 'https://github.com/ps3dev/PSL1GHT.git' "$WF"
grep -q 'Build and install the selected PSL1GHT revision' "$WF"
grep -q 'make -C app -j2' "$WF"
grep -q 'make -C app pkg' "$WF"
grep -q 'ps3vpnmanager.elf' "$WF"
grep -q 'ps3vpnmanager.self' "$WF"
grep -q 'ps3vpnmanager.pkg' "$WF"
grep -q 'collect-build-evidence.sh build-evidence' "$WF"
printf 'OK: workflow instala a revisao PSL1GHT selecionada e compila/empacota o aplicativo.\n'
