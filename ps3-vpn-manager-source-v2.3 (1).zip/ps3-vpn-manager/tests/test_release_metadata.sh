#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
grep -q '^\*\*Versão do pacote: 2\.3\*\*$' "$ROOT/README.md"
grep -q '^## Estado atual — versão 2\.3$' "$ROOT/README.md"
grep -q '^# Estado do projeto — versão 2\.3$' "$ROOT/docs/estado-do-projeto.md"
test -s "$ROOT/docs/rsx-first-frame-v1.8.md"
printf 'OK: metadados e documentação da versão 2.3 consistentes.\n'
