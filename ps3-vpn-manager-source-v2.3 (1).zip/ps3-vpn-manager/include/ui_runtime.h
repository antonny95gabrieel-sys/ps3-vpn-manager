#ifndef UI_RUNTIME_H
#define UI_RUNTIME_H

#include "ui_model.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Máscaras normalizadas. O adaptador PSL1GHT deverá convertê-las a partir
 * do relatório real do controle; este módulo não presume bits da libpad. */
enum {
    UI_KEY_UP     = 1u << 0,
    UI_KEY_DOWN   = 1u << 1,
    UI_KEY_LEFT   = 1u << 2,
    UI_KEY_RIGHT  = 1u << 3,
    UI_KEY_CROSS  = 1u << 4,
    UI_KEY_CIRCLE = 1u << 5
};

typedef struct {
    uint32_t previous_keys;
} ui_runtime_t;

void ui_runtime_init(ui_runtime_t *runtime);
/* Processa apenas a borda de pressionamento: manter um botão pressionado
 * não repete a ação a cada quadro. Retorna a ação do modelo, se houver. */
ui_action_t ui_runtime_update(ui_runtime_t *runtime, ui_model_t *model,
                              uint32_t current_keys);

#ifdef __cplusplus
}
#endif
#endif
