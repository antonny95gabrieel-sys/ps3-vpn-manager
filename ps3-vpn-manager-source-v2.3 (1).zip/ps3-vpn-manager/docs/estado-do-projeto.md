# Estado do projeto — versão 2.3

## Implementado na versão 2.2

- `app/Makefile` com metadados de aplicativo PSL1GHT, ícone e alvo `pkg`.
- `app/source/main.c` com entry point `main`, inicialização RSX e buffers duplos de vídeo.
- Backend de desenho por framebuffer CPU para os comandos CLEAR/RECT/TEXT/LINE do `ui_renderer`.
- Integração de `ui_model`, `ui_runtime`, `ui_view` e `ps3_pad_adapter`.
- Leitura de controle via `ioPadInit`, `ioPadGetInfo` e `ioPadGetData`.
- Callback de saída via `sysUtilRegisterCallback`/`SYSUTIL_EXIT_GAME`.
- Teste de sintaxe host do entry point com stubs e teste de contrato da estrutura PSL1GHT.
- Workflow atualizado para compilar o próprio aplicativo e gerar ELF/SELF/PKG, com manifesto SHA-256 dos artefatos.

**Validação atual:** testes host passaram. A compilação PPU/PSL1GHT remota não foi executada nesta conversa; por isso, ainda não existem binários reais do aplicativo nem evidência de execução no console.

## Implementado e testado no host

- Núcleo de estados e validação básica de configuração.
- Modelo de interface para início, configuração e diagnóstico.
- Runtime de entrada com detecção de borda de pressionamento.
- Adaptador `padData` → máscaras normalizadas, testado com stub.
- Modelo de comandos de desenho e despachante com validação integral do quadro.
- Verificador do SDK nos modos `--core`, `--graphics` e `--package`.
- Testes automatizados host: seis executáveis C e testes shell de preflight, Tiny3D, workflow, manifesto, metadados e entry point.
- Workflow manual de CI permite selecionar branch/tag/SHA para ps3dev, Tiny3D e PSL1GHT, registra revisões, compila o app e tenta gerar ELF/SELF/PKG (execução real ainda não confirmada).
- Script `tools/install-tiny3d.sh` para instalar apenas as bibliotecas Tiny3D/libfont, sem samples.
- Preflight `--graphics` verifica headers e bibliotecas Tiny3D e libfont.
- Teste host simulado para o contrato do instalador Tiny3D.

## Ainda não comprovado / ainda não implementado

- Compilação do entry point contra headers e bibliotecas reais do SDK PPU.
- Execução real de RSX/framebuffer, leitura física de libpad e callback XMB no Super Slim.
- ELF, SELF e PKG do VPN Manager: ainda não gerados nesta sessão.
- Motor WireGuard e túnel funcional.
- Integração de rotas/DNS/firewall global do GameOS.

## Alterações da versão 1.6

O workflow aceita referências explícitas para os repositórios ps3dev e Tiny3D, inclusive SHA de commit. Em vez de depender somente da branch padrão, inicializa o repositório, faz fetch da referência solicitada e faz checkout detached do commit obtido. Os SHAs efetivos são preservados nos artefatos. Isso permite reproduzir uma execução quando os SHAs forem informados novamente.

O teste `tests/test_workflow_contract.sh` verifica estaticamente os inputs, fetch, registro de SHAs e upload de artefatos. Ele não executa o workflow.

## Limites desta versão

A versão 1.6 amplia o workflow para instalar as bibliotecas Tiny3D/libfont após o build do ambiente ps3dev. As revisões obtidas dos repositórios são registradas para auditoria; ainda não estão fixadas em hashes no workflow. O log do SDK e a validação gráfica são preservados como artefatos mesmo quando uma etapa falha.

O workflow ainda precisa ser executado no repositório GitHub para produzir evidência real. A sessão atual não tem acesso operacional ao repositório nem executa GitHub Actions; portanto, não houve build real da toolchain nem instalação real do Tiny3D nesta etapa. O novo teste de instalador usa um `make` simulado; os demais testes locais continuam sendo testes host.

## Próximo marco

Executar o workflow atualizado, corrigir eventuais incompatibilidades apontadas pelo compilador PPU, gerar o primeiro PKG real e testá-lo no console. A validação de framebuffer, controle e encerramento ainda dependerá do PS3 físico.


## Atualização da versão 1.8

- Corrigida a divergência de versão entre o README e este documento.
- Documentado o ciclo RSX necessário para o primeiro quadro: criar contexto,
  configurar modo de vídeo, definir flip mode, alocar buffers alinhados em
  memória RSX, obter offsets, registrar buffers de exibição, limpar o estado
  de flip, renderizar no buffer não exibido, enviar flip, flush, aguardar e
  selecionar o próximo render target.
- Adicionado teste automático de consistência dos metadados do pacote.

O ciclo acima é uma referência técnica para implementação, não código já
executado no PS3. Nenhuma inicialização RSX/Tiny3D foi compilada nesta etapa.


## Atualização da versão 1.9

- O README e este documento passam a declarar a mesma versão do pacote.
- Binários de testes host foram retirados do ZIP de distribuição.
- Os testes host continuam reproduzíveis pelo `Makefile.host`.
- Nenhuma aplicação PSL1GHT, ELF, SELF ou PKG foi produzida.


## Atualização da versão 2.0

- Workflow aceita `psl1ght_ref` (branch, tag ou SHA).
- Baixa a revisão selecionada do repositório oficial PSL1GHT.
- Compila o sample oficial `samples/graphics/rsxtest` depois da preparação do
  SDK e da validação das bibliotecas gráficas.
- Exige os arquivos `rsxtest.elf` e `rsxtest.self` e os inclui nos artefatos
  quando o build conclui.
- Registra o SHA efetivo do PSL1GHT e o log da compilação.
- Adicionado teste local estático do contrato do workflow.

**Interpretação correta:** se esse job passar, teremos evidência de que a
toolchain consegue compilar um sample gráfico oficial. Isso não comprova ainda
que o código do VPN Manager compila, que o SELF inicia no console, nem que o
framebuffer funciona no Super Slim. O aplicativo próprio ainda não tem entry
point PSL1GHT, renderer Tiny3D integrado, ELF, SELF ou PKG.


## Atualização da versão 2.1

- O workflow chama `tools/collect-build-evidence.sh` após compilar o sample RSX oficial.
- O manifesto `build-evidence/manifest.sha256.tsv` registra caminho relativo, tamanho e SHA-256 de `rsxtest.elf`, `rsxtest.self`, revisões dos três repositórios e logs da execução.
- A geração falha se qualquer evidência obrigatória estiver ausente ou vazia.
- Adicionado teste host com fixtures, incluindo caso negativo para SELF ausente.

**Limite:** isso melhora a auditabilidade da validação de toolchain, mas não cria nem valida o executável do PS3 VPN Manager. O app ainda não tem entry point próprio, ELF, SELF ou PKG.


## Atualização da versão 2.2

A versão 2.2 adiciona o primeiro entry point próprio. O código usa as APIs atuais do PSL1GHT encontradas nos headers `rsx/rsx.h`, `sysutil/video.h`, `sysutil/sysutil.h` e `io/pad.h`, e liga o framebuffer ao renderer genérico do projeto. O desenho é feito diretamente na memória do framebuffer com uma fonte bitmap 5x7, sem Tiny3D. O workflow compila o projeto e solicita o empacotamento.

**Não confundir preparação com validação:** a sintaxe foi checada no host com stubs, mas a toolchain PPU não foi executada nesta conversa. A criação de ELF/SELF/PKG depende da execução do workflow; a operação do RSX e do controle depende de teste no hardware real.


## Atualização da versão 2.3

- Stub de `io/pad.h` ampliado para refletir a union e os campos `BTN_*` da estrutura oficial `padData`.
- Adicionado teste `test_sdk_api_stub.sh` para conferir o contrato estrutural usado pelo adaptador de controle.
- Adicionada auditoria das APIs PSL1GHT consultadas, com hashes dos blobs e limites explícitos da verificação.

**Limite:** a auditoria foi feita contra headers oficiais, mas não houve compilação PPU, link, SELF/PKG nem execução no PS3.
