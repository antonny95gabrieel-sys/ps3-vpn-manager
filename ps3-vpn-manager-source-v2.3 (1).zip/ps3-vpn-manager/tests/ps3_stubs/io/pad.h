#ifndef TEST_IO_PAD_H
#define TEST_IO_PAD_H
#include <ppu-types.h>

/* Recorte estrutural fiel ao PSL1GHT ppu/include/io/pad.h.
 * Os nomes e a organização da union são preservados para que os testes
 * usem os mesmos campos BTN_* que o aplicativo usa no SDK real.
 */
#define MAX_PADS 127
#define MAX_PORT_NUM 7

typedef struct _pad_info {
    u32 max;
    u32 connected;
    u32 info;
    u16 vendor_id[MAX_PADS];
    u16 product_id[MAX_PADS];
    u8 status[MAX_PADS];
} padInfo;

typedef struct _pad_data {
    s32 len;
    union {
        u16 button[64];
        struct {
            u16 zeroes;
            unsigned int : 8;
            unsigned int seven : 4;
            unsigned int halflen : 4;
            unsigned int : 8;
            unsigned int BTN_LEFT : 1;
            unsigned int BTN_DOWN : 1;
            unsigned int BTN_RIGHT : 1;
            unsigned int BTN_UP : 1;
            unsigned int BTN_START : 1;
            unsigned int BTN_R3 : 1;
            unsigned int BTN_L3 : 1;
            unsigned int BTN_SELECT : 1;
            unsigned int : 8;
            unsigned int BTN_SQUARE : 1;
            unsigned int BTN_CROSS : 1;
            unsigned int BTN_CIRCLE : 1;
            unsigned int BTN_TRIANGLE : 1;
            unsigned int BTN_R1 : 1;
            unsigned int BTN_L1 : 1;
            unsigned int BTN_R2 : 1;
            unsigned int BTN_L2 : 1;
            unsigned int ANA_R_H : 16;
            unsigned int ANA_R_V : 16;
            unsigned int ANA_L_H : 16;
            unsigned int ANA_L_V : 16;
            unsigned int PRE_RIGHT : 16;
            unsigned int PRE_LEFT : 16;
            unsigned int PRE_UP : 16;
            unsigned int PRE_DOWN : 16;
            unsigned int PRE_TRIANGLE : 16;
            unsigned int PRE_CIRCLE : 16;
            unsigned int PRE_CROSS : 16;
            unsigned int PRE_SQUARE : 16;
            unsigned int PRE_L1 : 16;
            unsigned int PRE_R1 : 16;
            unsigned int PRE_L2 : 16;
            unsigned int PRE_R2 : 16;
            unsigned int SENSOR_X : 16;
            unsigned int SENSOR_Y : 16;
            unsigned int SENSOR_Z : 16;
            unsigned int SENSOR_G : 16;
            unsigned int BTN_BDLEN : 16;
            unsigned int BTN_BDCODE : 16;
            u8 reserved[76];
        };
    };
} padData;

s32 ioPadInit(u32 max);
s32 ioPadEnd(void);
s32 ioPadGetInfo(padInfo *info);
s32 ioPadGetData(u32 port, padData *data);
#endif
