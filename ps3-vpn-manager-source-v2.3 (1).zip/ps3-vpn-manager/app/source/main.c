#include <malloc.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>

#include <ppu-types.h>
#include <io/pad.h>
#include <rsx/rsx.h>
#include <sysutil/video.h>
#include <sysutil/sysutil.h>

#include "ui_model.h"
#include "ui_runtime.h"
#include "ui_view.h"
#include "ui_renderer.h"
#include "ps3_pad_adapter.h"

typedef struct {
    u32 *pixels;
    u32 width;
    u32 height;
} framebuffer_t;

static gcmContextData *g_context;
static videoResolution g_resolution;
static u32 *g_buffers[2];
static int g_current_buffer;
static volatile int g_running = 1;
static ui_model_t g_model;
static ui_runtime_t g_runtime;

static u32 color_to_xrgb(unsigned int rgba)
{
    return ((rgba >> 8) & 0x00FFFFFFu);
}

static void put_pixel(framebuffer_t *fb, int x, int y, u32 color)
{
    if (fb == NULL || fb->pixels == NULL) return;
    if (x < 0 || y < 0 || (u32)x >= fb->width || (u32)y >= fb->height) return;
    fb->pixels[(u32)y * fb->width + (u32)x] = color;
}

static void fill_rect(framebuffer_t *fb, int x, int y, int w, int h, u32 color)
{
    int row, col;
    if (fb == NULL || w <= 0 || h <= 0) return;
    for (row = 0; row < h; ++row)
        for (col = 0; col < w; ++col)
            put_pixel(fb, x + col, y + row, color);
}

/* Fonte bitmap 5x7 mínima; os textos da interface são normalizados para ASCII. */
static const u8 *glyph_rows(char c)
{
    static const u8 blank[7] = {0,0,0,0,0,0,0};
#define G(ch,a,b,c1,d,e,f,g) case ch: { static const u8 r[7]={a,b,c1,d,e,f,g}; return r; }
    switch (c) {
    G('A',14,17,17,31,17,17,17) G('B',30,17,17,30,17,17,30)
    G('C',14,17,16,16,16,17,14) G('D',30,17,17,17,17,17,30)
    G('E',31,16,16,30,16,16,31) G('F',31,16,16,30,16,16,16)
    G('G',14,17,16,23,17,17,15) G('H',17,17,17,31,17,17,17)
    G('I',14,4,4,4,4,4,14) G('J',7,2,2,2,18,18,12)
    G('K',17,18,20,24,20,18,17) G('L',16,16,16,16,16,16,31)
    G('M',17,27,21,21,17,17,17) G('N',17,25,25,21,19,19,17)
    G('O',14,17,17,17,17,17,14) G('P',30,17,17,30,16,16,16)
    G('Q',14,17,17,17,21,18,13) G('R',30,17,17,30,20,18,17)
    G('S',15,16,16,14,1,1,30) G('T',31,4,4,4,4,4,4)
    G('U',17,17,17,17,17,17,14) G('V',17,17,17,17,17,10,4)
    G('W',17,17,17,21,21,21,10) G('X',17,17,10,4,10,17,17)
    G('Y',17,17,10,4,4,4,4) G('Z',31,1,2,4,8,16,31)
    G('0',14,17,19,21,25,17,14) G('1',4,12,4,4,4,4,14)
    G('2',14,17,1,2,4,8,31) G('3',30,1,1,14,1,1,30)
    G('4',2,6,10,18,31,2,2) G('5',31,16,16,30,1,1,30)
    G('6',14,16,16,30,17,17,14) G('7',31,1,2,4,8,8,8)
    G('8',14,17,17,14,17,17,14) G('9',14,17,17,15,1,1,14)
    G(':',0,4,4,0,4,4,0) G('.',0,0,0,0,0,6,6)
    G('-',0,0,0,31,0,0,0) G('/',1,2,2,4,8,8,16)
    G('(',2,4,8,8,8,4,2) G(')',8,4,2,2,2,4,8)
    default: return blank;
    }
#undef G
}

static void draw_text(framebuffer_t *fb, float fx, float fy, float fw,
                      float fh, unsigned int rgba, int centered, const char *text)
{
    int x, y, scale = 2, i, row, col;
    int length;
    u32 color = color_to_xrgb(rgba);
    if (fb == NULL || text == NULL) return;
    length = (int)strlen(text);
    if (length <= 0) return;
    if ((float)(length * 12) > fw) scale = 1;
    x = (int)fx;
    y = (int)fy;
    if (centered) x += ((int)fw - length * 6 * scale) / 2;
    if ((float)(7 * scale) > fh) return;

    for (i = 0; i < length; ++i) {
        char ch = (char)toupper((unsigned char)text[i]);
        const u8 *rows = glyph_rows(ch);
        for (row = 0; row < 7; ++row) {
            for (col = 0; col < 5; ++col) {
                if ((rows[row] & (1u << (4 - col))) != 0u)
                    fill_rect(fb, x + col * scale, y + row * scale,
                              scale, scale, color);
            }
        }
        x += 6 * scale;
        if ((float)(x - (int)fx) >= fw) break;
    }
}

static void backend_clear(void *context, unsigned int color, float width, float height)
{
    framebuffer_t *fb = (framebuffer_t *)context;
    (void)width; (void)height;
    if (fb != NULL) fill_rect(fb, 0, 0, (int)fb->width, (int)fb->height,
                              color_to_xrgb(color));
}

static void backend_rectangle(void *context, float x, float y, float w, float h,
                              unsigned int color)
{
    fill_rect((framebuffer_t *)context, (int)x, (int)y, (int)w, (int)h,
              color_to_xrgb(color));
}

static void backend_text(void *context, float x, float y, float w, float h,
                         unsigned int color, int centered, const char *value)
{
    draw_text((framebuffer_t *)context, x, y, w, h, color, centered, value);
}

static void backend_line(void *context, float x, float y, float w, float h,
                         unsigned int color)
{
    fill_rect((framebuffer_t *)context, (int)x, (int)y, (int)w,
              (h < 2.0f) ? 2 : (int)h, color_to_xrgb(color));
}

static void wait_flip(void)
{
    while (gcmGetFlipStatus() != 0) usleep(200);
    gcmResetFlipStatus();
}

static int flip(int index)
{
    if (gcmSetFlip(g_context, index) != 0) return -1;
    rsxFlushBuffer(g_context);
    gcmSetWaitFlip(g_context);
    return 0;
}

static int init_video(void)
{
    void *host_addr = memalign(1024 * 1024, 8 * 1024 * 1024);
    videoState state;
    videoConfiguration config;
    u32 offsets[2];
    u32 buffer_size;
    int i;

    if (host_addr == NULL) return -1;
    if (rsxInit(&g_context, 0x80000, 8 * 1024 * 1024, host_addr) != 0) return -1;
    if (videoGetState(VIDEO_PRIMARY, 0, &state) != 0 ||
        state.state != VIDEO_STATE_ENABLED) return -1;
    if (videoGetResolution(state.displayMode.resolution, &g_resolution) != 0) return -1;

    memset(&config, 0, sizeof(config));
    config.resolution = state.displayMode.resolution;
    config.format = VIDEO_BUFFER_FORMAT_XRGB;
    config.aspect = state.displayMode.aspect;
    config.pitch = (u32)g_resolution.width * 4;
    if (videoConfigure(VIDEO_PRIMARY, &config, NULL, 0) != 0) return -1;

    gcmSetFlipMode(GCM_FLIP_VSYNC);
    buffer_size = (u32)g_resolution.width * (u32)g_resolution.height * 4;
    for (i = 0; i < 2; ++i) {
        g_buffers[i] = (u32 *)rsxMemalign(64, buffer_size);
        if (g_buffers[i] == NULL) return -1;
        if (rsxAddressToOffset(g_buffers[i], &offsets[i]) != 0) return -1;
        if (gcmSetDisplayBuffer((u32)i, offsets[i],
                                (u32)g_resolution.width * 4,
                                g_resolution.width, g_resolution.height) != 0) return -1;
    }
    gcmResetFlipStatus();
    g_current_buffer = 0;
    return flip(1);
}

static int render_frame(void)
{
    framebuffer_t fb;
    ui_draw_command_t commands[64];
    ui_renderer_backend_t backend;
    ui_viewport_t viewport;
    size_t count;
    int result;

    wait_flip();
    fb.pixels = g_buffers[g_current_buffer];
    fb.width = g_resolution.width;
    fb.height = g_resolution.height;
    viewport.width = (float)fb.width;
    viewport.height = (float)fb.height;

    count = ui_view_build(&g_model, viewport, commands,
                          sizeof(commands) / sizeof(commands[0]));
    if (count > sizeof(commands) / sizeof(commands[0])) return -1;

    backend.clear = backend_clear;
    backend.rectangle = backend_rectangle;
    backend.text = backend_text;
    backend.line = backend_line;
    backend.context = &fb;
    result = (int)ui_renderer_submit(&backend, commands, count);
    if (result != (int)UI_RENDER_OK) return -1;

    if (flip(g_current_buffer) != 0) return -1;
    g_current_buffer ^= 1;
    return 0;
}

static void event_callback(u64 status, u64 param, void *userdata)
{
    (void)param;
    (void)userdata;
    if (status == SYSUTIL_EXIT_GAME) g_running = 0;
}

s32 main(s32 argc, const char *argv[])
{
    padInfo pad_info;
    padData pad_data;
    int pad_initialized = 0;
    (void)argc;
    (void)argv;

    ui_model_init(&g_model);
    (void)strncpy(g_model.server_label, "Motor VPN nao integrado",
                  sizeof(g_model.server_label) - 1u);
    ui_runtime_init(&g_runtime);

    if (sysUtilRegisterCallback(SYSUTIL_EVENT_SLOT0, event_callback, NULL) != 0) return -1;
    if (init_video() != 0) {
        sysUtilUnregisterCallback(SYSUTIL_EVENT_SLOT0);
        return -1;
    }
    if (ioPadInit(7) == 0) pad_initialized = 1;

    while (g_running) {
        u32 keys = 0;
        int i;
        if (pad_initialized && ioPadGetInfo(&pad_info) == 0) {
            for (i = 0; i < MAX_PORT_NUM; ++i) {
                if (pad_info.status[i]) {
                    if (ioPadGetData(i, &pad_data) == 0) {
                        keys = ps3_pad_to_ui_keys(&pad_data);
                        break;
                    }
                }
            }
        }
        (void)ui_runtime_update(&g_runtime, &g_model, keys);
        if (render_frame() != 0) break;
        sysUtilCheckCallback();
        usleep(10000);
    }

    if (pad_initialized) ioPadEnd();
    sysUtilUnregisterCallback(SYSUTIL_EVENT_SLOT0);
    return 0;
}
