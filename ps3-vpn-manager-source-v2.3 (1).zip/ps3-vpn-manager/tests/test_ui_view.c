#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "ui_view.h"

int main(void)
{
    ui_model_t ui;
    ui_viewport_t vp = {1280.0f, 720.0f};
    ui_draw_command_t commands[64];
    size_t count, i;
    int saw_title = 0, saw_offline = 0;

    ui_model_init(&ui);
    count = ui_view_build(&ui, vp, commands, 64);
    assert(count > 10 && count <= 64);
    for (i = 0; i < count; ++i) {
        if (strcmp(commands[i].text, "PS3 VPN MANAGER") == 0) saw_title = 1;
        if (strcmp(commands[i].text, "Desconectado") == 0) saw_offline = 1;
        assert(commands[i].w >= 0.0f && commands[i].h >= 0.0f);
    }
    assert(saw_title && saw_offline);

    ui.screen = UI_SCREEN_DIAGNOSTICS;
    count = ui_view_build(&ui, vp, commands, 64);
    assert(count > 5);
    saw_offline = 0;
    for (i = 0; i < count; ++i)
        if (strstr(commands[i].text, "NAO VERIFICADO") != NULL) saw_offline = 1;
    assert(saw_offline);
    assert(ui_view_build(&ui, (ui_viewport_t){100.0f, 100.0f}, commands, 64) == 0);
    puts("OK: layout de interface e mensagens de seguranca verificadas");
    return 0;
}
