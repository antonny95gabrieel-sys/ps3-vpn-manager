#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP/build-evidence"
for name in ps3vpnmanager.elf ps3vpnmanager.self ps3vpnmanager.pkg ps3dev-build.log ps3-sdk-core.log ps3-sdk-graphics.log psl1ght-build-install.log ps3-vpn-manager-build.log ps3-vpn-manager-package.log; do
  printf 'fixture:%s\n' "$name" > "$TMP/build-evidence/$name"
done
for name in ps3dev-revision.txt tiny3d-revision.txt psl1ght-revision.txt; do
  printf '0123456789abcdef0123456789abcdef01234567\n' > "$TMP/$name"
done

# Run against a temporary project-shaped tree, without changing the source tree.
mkdir -p "$TMP/tools"
cp "$ROOT/tools/collect-build-evidence.sh" "$TMP/tools/"
"$TMP/tools/collect-build-evidence.sh" "$TMP/build-evidence"
MANIFEST="$TMP/build-evidence/manifest.sha256.tsv"
grep -q '^format[[:space:]]ps3-vpn-manager-build-evidence-v2$' "$MANIFEST"
[ "$(grep -c '^build-evidence/\|^[a-z].*-revision.txt' "$MANIFEST")" -eq 12 ]
EXPECTED=$(sha256sum "$TMP/build-evidence/ps3vpnmanager.elf" | awk '{print $1}')
grep -q "^build-evidence/ps3vpnmanager.elf[[:space:]][0-9][0-9]*[[:space:]]$EXPECTED$" "$MANIFEST"

rm -f "$TMP/build-evidence/ps3vpnmanager.self"
if "$TMP/tools/collect-build-evidence.sh" "$TMP/build-evidence" >/dev/null 2>&1; then
  echo 'ERRO: manifesto aceitou SELF do aplicativo ausente.' >&2
  exit 1
fi
printf 'OK: manifesto SHA-256 registra evidências e rejeita arquivos ausentes.\n'
