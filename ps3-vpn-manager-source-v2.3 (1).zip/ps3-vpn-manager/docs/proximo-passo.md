# Próximo passo técnico

1. Confirmar o tipo de firmware/HFW e identificar a versão exata do HEN sem atualizar o console.
2. Criar a primeira interface PSL1GHT como aplicação independente no XMB (estado offline/demonstração claramente indicado).
3. Compilar a interface para SELF e PKG com uma toolchain ps3dev/PSL1GHT.
4. Testar instalação e inicialização no Super Slim com HEN.
5. Só depois estudar a integração de rede e a implementação WireGuard.

## Por que a interface vem primeiro?
A interface é um componente de risco menor e pode ser validada sem fingir que a VPN já funciona. O maior risco é global: um processo homebrew não recebe automaticamente controle sobre as rotas, DNS ou firewall de todos os processos do GameOS.

## Critério de sucesso da primeira etapa
- O PKG instala no firmware-alvo.
- O ícone aparece no XMB.
- A aplicação abre e encerra sem congelar o console.
- A tela identifica explicitamente que a VPN ainda não está implementada.
