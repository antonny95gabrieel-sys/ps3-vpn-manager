#include "ps3_pad_adapter.h"
#include "ui_runtime.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    padData pad;
    memset(&pad, 0, sizeof(pad));
    assert(ps3_pad_to_ui_keys(0) == 0u);
    assert(ps3_pad_to_ui_keys(&pad) == 0u);

    pad.BTN_UP = 1;
    pad.BTN_CROSS = 1;
    assert(ps3_pad_to_ui_keys(&pad) == (UI_KEY_UP | UI_KEY_CROSS));

    memset(&pad, 0, sizeof(pad));
    pad.BTN_DOWN = 1;
    pad.BTN_LEFT = 1;
    pad.BTN_RIGHT = 1;
    pad.BTN_CIRCLE = 1;
    assert(ps3_pad_to_ui_keys(&pad) ==
           (UI_KEY_DOWN | UI_KEY_LEFT | UI_KEY_RIGHT | UI_KEY_CIRCLE));

    puts("OK: adaptador libpad -> runtime verificado com stub de host");
    return 0;
}
