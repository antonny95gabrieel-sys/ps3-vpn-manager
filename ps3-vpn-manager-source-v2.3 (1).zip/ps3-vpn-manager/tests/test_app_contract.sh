#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
APP="$ROOT/app"
need() { grep -Fq -- "$1" "$APP/source/main.c" || { echo "ERRO: app sem requisito: $1" >&2; exit 1; }; }
need 's32 main(s32 argc, const char *argv[])'
need 'sysUtilRegisterCallback(SYSUTIL_EVENT_SLOT0, event_callback, NULL)'
need 'SYSUTIL_EXIT_GAME'
need 'ioPadInit(7)'
need 'ioPadGetInfo(&pad_info)'
need 'ioPadGetData(i, &pad_data)'
need 'ui_runtime_update(&g_runtime, &g_model, keys)'
need 'ui_view_build(&g_model, viewport, commands'
need 'ui_renderer_submit(&backend, commands, count)'
grep -Fq 'APPID := VPNM00001' "$APP/Makefile"
grep -Fq '$(OUTPUT).pkg' "$APP/Makefile"
test -s "$APP/pkgfiles/ICON0.PNG"
printf 'OK: contrato da aplicacao PSL1GHT presente.\n'
