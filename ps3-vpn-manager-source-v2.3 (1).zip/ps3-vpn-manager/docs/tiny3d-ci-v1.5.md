# Validação Tiny3D no CI — versão 1.5

## Objetivo

Instalar e validar as bibliotecas gráficas exigidas para a futura interface, sem ainda compilar o aplicativo.

## O que o workflow faz

1. Constrói o ambiente ps3dev/PSL1GHT no runner Ubuntu.
2. Executa o preflight `--core`.
3. Clona o repositório `wargio/tiny3D` e registra o SHA obtido.
4. Executa `tools/install-tiny3d.sh`, que chama `make install` somente nos diretórios `lib` e `libfont`.
5. Executa o preflight `--graphics`, que exige os headers e arquivos estáticos das duas bibliotecas.
6. Publica logs e revisões como artefatos, inclusive quando uma etapa falha.

Os samples Tiny3D não são construídos nesta fase porque alguns dependem de bibliotecas adicionais, como ps3soundlib. O objetivo aqui é somente validar as duas bibliotecas necessárias à aplicação.

## Revisões e reprodutibilidade

O workflow clona as branches padrão com `--depth 1` e grava os SHAs obtidos em `ps3dev-revision.txt` e `tiny3d-revision.txt`. Isso permite identificar o código usado em cada execução, mas não garante que execuções futuras usem as mesmas revisões. Depois de uma execução bem-sucedida, os SHAs devem ser fixados no workflow para builds reproduzíveis.

## O que o teste host prova

`tests/test_tiny3d_install.sh` substitui `make` por um executável simulado que cria os quatro arquivos esperados. Ele verifica argumentos, caminhos e verificações de saída do script de instalação. **Não compila Tiny3D nem prova compatibilidade com o SDK real.**

## Critério de conclusão

A etapa só será considerada validada quando o workflow real terminar e `tools/check-ps3-sdk.sh --graphics` passar no runner com PPU toolchain e Tiny3D reais. Mesmo assim, ainda será necessário compilar um sample e testar no PS3 físico antes de integrar o renderer ao aplicativo.

## Referências

- PS3DEV: https://github.com/ps3dev/ps3dev — recomenda configurar `PS3DEV`, `PSL1GHT` e o `PATH`, e descreve o build do ambiente.
- Tiny3D: https://github.com/wargio/tiny3D — documenta que `make` instala `libtiny3d` e `libfont` e que os samples têm dependências adicionais.
