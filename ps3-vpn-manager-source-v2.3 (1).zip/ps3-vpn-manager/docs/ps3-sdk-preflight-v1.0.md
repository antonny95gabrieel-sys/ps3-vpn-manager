# Verificacao de ambiente PS3 — v1.0

O script `tools/check-ps3-sdk.sh` verifica, antes da compilacao, a presenca de:

- `PS3DEV`, `PSL1GHT` e `PORTLIBS` configurados;
- `ppu-gcc` no `PATH`;
- um utilitario de geracao SELF (`make_self_npdrm` ou `make_self`);
- arquivos de desenvolvimento do PSL1GHT;
- `tiny3d.h` e `libtiny3d.a` em `PORTLIBS`.

Uso:

```sh
export PS3DEV=/caminho/ps3dev
export PSL1GHT="$PS3DEV/psl1ght"
export PORTLIBS="$PS3DEV/portlibs/ppu"
export PATH="$PATH:$PS3DEV/bin:$PS3DEV/ppu/bin:$PSL1GHT/host/bin"
./tools/check-ps3-sdk.sh
```

Os caminhos acima são exemplos: a instalação real pode organizar as pastas de
outra forma. O script não baixa ferramentas, não altera o sistema e não cria
arquivos SELF/PKG. Ele apenas falha cedo quando falta uma dependência.

O projeto Tiny3D documenta a instalação das bibliotecas em `$PORTLIBS/lib` e
headers em `$PORTLIBS/include`. O PSL1GHT oficial informa que uma aplicação
normalmente gera ELF/SELF e que o empacotamento depende do alvo `pkg` definido
pelo Makefile do aplicativo. Ainda precisamos implementar o entry point e os
callbacks Tiny3D usando os headers efetivamente instalados antes de habilitar
uma compilação de produto.
