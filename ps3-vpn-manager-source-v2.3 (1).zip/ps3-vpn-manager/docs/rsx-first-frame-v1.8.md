# Primeiro quadro RSX — especificação técnica v1.8

## Objetivo

Definir a sequência de baixo nível que deverá ser implementada e testada antes
de integrar Tiny3D ao renderizador do PS3 VPN Manager.

## Sequência documentada

A documentação pública de `rsx.h` do PSL1GHT descreve este fluxo:

1. Criar o contexto RSX com `rsxInit`.
2. Consultar/configurar o modo de vídeo (`videoGetState` / `videoConfigure`).
3. Definir o modo de flip, normalmente sincronizado ao VSync.
4. Alocar dois buffers de cor em memória RSX, com alinhamento de 64 bytes.
5. Converter os endereços dos buffers em offsets com `rsxAddressToOffset`.
6. Registrar os buffers com `gcmSetDisplayBuffer`.
7. Resetar o estado de flip com `gcmResetFlipStatus`.
8. Para cada quadro, desenhar no buffer que não está sendo exibido.
9. Solicitar a troca com `gcmSetFlip`, executar `rsxFlushBuffer` e aguardar
   `gcmSetWaitFlip`.
10. Definir o próximo destino de renderização com `rsxSetSurface` e verificar
    o estado de flip antes de reutilizar o buffer.

A documentação também alerta que o tamanho de um buffer RGBA de 32 bits é
`largura * altura * 4`, e que a alocação deve respeitar os requisitos de
alinhamento da memória RSX.

## O que ainda precisa ser confirmado no build real

- Assinaturas e estruturas na revisão exata do PSL1GHT selecionada no CI.
- Forma de inicialização e limpeza do contexto RSX usada pelo sample oficial
  da mesma revisão.
- Formato de cor, pitch, offsets e configuração da superfície.
- Comportamento do framebuffer no PS3 Super Slim com o firmware/HEN informados.
- Retorno ao XMB e callback de encerramento.

## Regra de implementação

Não copiar apenas uma sequência de nomes de função para um `main.c` presumido.
A implementação deverá ser adaptada de um sample oficial que compile na revisão
fixada do SDK. Depois, substituir gradualmente o desenho do sample pelos
comandos do `ui_renderer`.

## Limite desta especificação

Este documento não constitui renderer, não foi compilado para PPU e não produz
ELF, SELF ou PKG. O primeiro quadro só poderá ser considerado implementado
quando o workflow compilar o executável e o hardware apresentar a imagem.
