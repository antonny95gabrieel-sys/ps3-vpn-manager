# Como confirmar o firmware do PS3

No XMB, abra:

**Configurações → Configurações do sistema → Informações do sistema**.

Anote a versão do software do sistema exibida nessa tela. Não atualize o console para tentar descobrir a versão.

A versão do firmware/HFW e a versão do PS3HEN são informações diferentes. O número informado como HEN 3.9.0 deve ser confirmado separadamente; não vamos deduzir o firmware a partir dele.

Se possível, envie uma foto da tela de Informações do sistema. Oculte qualquer identificador ou dado pessoal que apareça.
