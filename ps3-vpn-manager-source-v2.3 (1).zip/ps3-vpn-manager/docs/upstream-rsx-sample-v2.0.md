# Validação com sample RSX oficial — versão 2.1

## Fonte de referência

O workflow usa `ps3dev/PSL1GHT`, diretório
`samples/graphics/rsxtest`. O Makefile do sample inclui `$(PSL1GHT)/ppu_rules`,
usa compiladores PPU/C++, liga bibliotecas RSX/GCM e define regras para gerar
ELF e SELF. O `main.cpp` do sample registra um callback de saída e um callback
do sysutil, além de inicializar o fluxo gráfico RSX.

Referências upstream consultadas (branch `master`; o CI registra o SHA real da
revisão selecionada):

- https://github.com/ps3dev/PSL1GHT/tree/master/samples/graphics/rsxtest
- https://github.com/ps3dev/PSL1GHT/blob/master/samples/graphics/rsxtest/Makefile
- https://github.com/ps3dev/PSL1GHT/blob/master/samples/graphics/rsxtest/source/main.cpp

## O que o workflow fará

1. Buscar a referência indicada em `psl1ght_ref`.
2. Registrar o SHA efetivo.
3. Executar `make clean` e `make` no diretório do sample.
4. Exigir `rsxtest.elf` e `rsxtest.self` não vazios.
5. Gerar manifesto SHA-256 com tamanhos, hashes, revisões e logs.
6. Publicar executáveis, manifesto e logs como artefatos de evidência.

## O que essa validação não faz

- Não compila o PS3 VPN Manager.
- Não prova que o sample funciona no CECH-4014B/HEN do usuário.
- Não gera um PKG do nosso aplicativo.
- Não implementa o backend Tiny3D nem a integração WireGuard.

O sample é usado como referência de toolchain e fluxo RSX; sua lógica gráfica
complexa não deve ser copiada para o app. Depois de um CI verde, o próximo passo
é criar um alvo de aplicação mínimo próprio, inicialmente com o entry point,
callback XMB e entrada libpad, e só então integrar a interface.


## Manifesto de evidências — versão 2.1

`tools/collect-build-evidence.sh build-evidence` exige os dois binários e os arquivos de revisão/log esperados. O manifesto TSV resultante não é uma assinatura digital nem prova que o código é confiável; ele permite detectar alterações acidentais e associar os artefatos aos hashes e revisões registrados.
