# Backend de renderização — versão 0.9

A versão 0.9 adiciona `ui_renderer.h` e `ui_renderer.c`. O módulo recebe a lista
`ui_draw_command_t` produzida por `ui_view_build` e encaminha cada comando para
callbacks fornecidos por um backend: limpar, retângulo, texto e linha.

O módulo verifica argumentos nulos, callbacks ausentes e tipos de comando
inválidos. Seu teste host usa callbacks de gravação e confirma que os quatro
tipos chegam ao backend com coordenadas, dimensões, cores e texto preservados.

**Limite importante:** isso ainda não é um backend Tiny3D/RSX. Nenhuma função
gráfica do PS3 é chamada por este módulo. A próxima integração deve implementar
os callbacks usando as APIs reais da versão instalada do Tiny3D/PSL1GHT e ser
compilada contra esses headers. Não há ELF, SELF ou PKG nesta versão.


## Alteração na v1.0

O despacho foi dividido em duas passagens. Primeiro, todas as operações são
validadas; somente se todas forem válidas o backend recebe os callbacks. Isso
evita deixar a tela parcialmente atualizada quando um comando posterior é
inválido ou não possui callback.
