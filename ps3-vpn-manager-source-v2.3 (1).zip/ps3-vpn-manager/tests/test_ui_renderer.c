#include "ui_renderer.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    unsigned int calls[4];
    unsigned int last_color;
    char last_text[80];
    int last_centered;
} recorder_t;

static void on_clear(void *p, unsigned int color, float w, float h)
{
    recorder_t *r = (recorder_t *)p;
    assert(w == 1280.0f && h == 720.0f);
    ++r->calls[0]; r->last_color = color;
}
static void on_rect(void *p, float x, float y, float w, float h, unsigned int color)
{
    recorder_t *r = (recorder_t *)p;
    assert(x == 10.0f && y == 20.0f && w == 300.0f && h == 40.0f);
    ++r->calls[1]; r->last_color = color;
}
static void on_text(void *p, float x, float y, float w, float h,
                    unsigned int color, int centered, const char *value)
{
    recorder_t *r = (recorder_t *)p;
    assert(x == 15.0f && y == 25.0f && w == 200.0f && h == 30.0f);
    ++r->calls[2]; r->last_color = color; r->last_centered = centered;
    (void)snprintf(r->last_text, sizeof(r->last_text), "%s", value);
}
static void on_line(void *p, float x, float y, float w, float h, unsigned int color)
{
    recorder_t *r = (recorder_t *)p;
    assert(x == 5.0f && y == 6.0f && w == 100.0f && h == 2.0f);
    ++r->calls[3]; r->last_color = color;
}

int main(void)
{
    recorder_t rec;
    ui_renderer_backend_t backend;
    ui_draw_command_t commands[4];
    memset(&rec, 0, sizeof(rec));
    memset(&backend, 0, sizeof(backend));
    memset(commands, 0, sizeof(commands));
    backend.context = &rec;
    backend.clear = on_clear; backend.rectangle = on_rect;
    backend.text = on_text; backend.line = on_line;

    commands[0].kind = UI_DRAW_CLEAR;
    commands[0].w = 1280.0f; commands[0].h = 720.0f;
    commands[0].color_rgba = 0x112233FFu;
    commands[1].kind = UI_DRAW_RECT;
    commands[1].x = 10.0f; commands[1].y = 20.0f;
    commands[1].w = 300.0f; commands[1].h = 40.0f;
    commands[1].color_rgba = 0x223344FFu;
    commands[2].kind = UI_DRAW_TEXT;
    commands[2].x = 15.0f; commands[2].y = 25.0f;
    commands[2].w = 200.0f; commands[2].h = 30.0f;
    commands[2].color_rgba = 0xFFFFFFFFu; commands[2].centered = 1;
    (void)strcpy(commands[2].text, "TESTE UI");
    commands[3].kind = UI_DRAW_LINE;
    commands[3].x = 5.0f; commands[3].y = 6.0f;
    commands[3].w = 100.0f; commands[3].h = 2.0f;
    commands[3].color_rgba = 0xAABBCCFFu;

    assert(ui_renderer_submit(&backend, commands, 4u) == UI_RENDER_OK);
    assert(rec.calls[0] == 1u && rec.calls[1] == 1u);
    assert(rec.calls[2] == 1u && rec.calls[3] == 1u);
    assert(strcmp(rec.last_text, "TESTE UI") == 0 && rec.last_centered == 1);
    assert(ui_renderer_submit(&backend, 0, 1u) == UI_RENDER_INVALID_ARGUMENT);
    backend.text = 0;
    {
        unsigned int before = rec.calls[0] + rec.calls[1] + rec.calls[2] + rec.calls[3];
        /* Callback ausente no fim do quadro: nada deve ter sido desenhado. */
        assert(ui_renderer_submit(&backend, commands, 4u) == UI_RENDER_MISSING_CALLBACK);
        assert(before == rec.calls[0] + rec.calls[1] + rec.calls[2] + rec.calls[3]);
    }
    backend.text = on_text;
    commands[0].kind = (ui_draw_kind_t)99;
    assert(ui_renderer_submit(&backend, commands, 1u) == UI_RENDER_UNKNOWN_COMMAND);
    commands[0].kind = UI_DRAW_CLEAR;
    commands[0].w = -1.0f;
    assert(ui_renderer_submit(&backend, commands, 1u) == UI_RENDER_INVALID_GEOMETRY);
    commands[0].w = 1280.0f;
    (void)memset(commands[2].text, 'X', sizeof(commands[2].text));
    assert(ui_renderer_submit(&backend, &commands[2], 1u) == UI_RENDER_INVALID_COMMAND_DATA);
    puts("OK: validacao integral, despacho e dados invalidos verificados");
    return 0;
}
