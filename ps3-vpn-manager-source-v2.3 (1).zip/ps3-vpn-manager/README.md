# PS3 VPN Manager — protótipo de arquitetura

**Versão do pacote: 2.3**

**Alvo:** PlayStation 3 Super Slim, software do sistema informado como 4.88; HEN declarado como 3.9.0 (identificação ainda precisa ser confirmada).

**Objetivo:** aplicativo iniciável pelo XMB para gerenciar uma conexão WireGuard e, como requisito principal, encaminhar com segurança o tráfego de todo o GameOS pelo túnel.

## Estado atual — versão 2.3

A versão 2.3 corrige o stub de libpad usado nos testes host para espelhar a union e os campos de `padData` do header oficial. Foi adicionada uma auditoria das assinaturas e metadados do PSL1GHT em `docs/sdk-api-audit-v2.3.md`. Essa conferência reduz o risco de os testes aceitarem uma estrutura artificialmente diferente, mas não substitui compilação PPU.

Este pacote é código-fonte e documentação. **Ainda não é um PKG instalável.** A versão 2.2 adicionou `app/source/main.c` e `app/Makefile`: um entry point PSL1GHT com inicialização RSX, framebuffer duplo, desenho por CPU de retângulos/texto, leitura libpad, integração com `ui_model`/`ui_runtime`/`ui_view`/`ui_renderer` e callback de encerramento do sistema. O ponto de entrada passou por verificação sintática no host usando stubs compatíveis com os nomes das APIs; isso não substitui a compilação com os headers e bibliotecas reais. O workflow manual foi alterado para compilar o próprio aplicativo, gerar ELF/SELF e tentar gerar o PKG, além de criar um manifesto SHA-256. Essa execução remota ainda não foi realizada nesta conversa. Portanto, não há ELF, SELF ou PKG real disponível. O motor WireGuard e a integração de rede global GameOS continuam ausentes; o aplicativo ainda não cria túnel nem protege o console.

## Arquitetura

1. Núcleo de estados e validação de configuração.
2. Interface PSL1GHT iniciável pelo XMB.
3. Motor WireGuard compatível com a arquitetura PPU do PS3.
4. Adaptador de rede para integração global no GameOS — viabilidade ainda não comprovada.
5. DNS pelo túnel e política fail-closed.
6. Compilação SELF/PKG e testes no hardware real.

## Compilar o teste do núcleo em um computador comum

```sh
cc -std=c11 -Wall -Wextra -Werror -Iinclude src/vpn_state.c tests/test_vpn_state.c -o test_vpn_state
./test_vpn_state
```

Isso testa somente a máquina de estados no computador. Não gera um executável PS3.

## Requisitos para produzir um PKG PS3

É necessária uma toolchain PS3 compatível, incluindo ps3dev/PSL1GHT e utilitários de SELF/PKG. O SDK oficial do PSL1GHT descreve a compilação de aplicações e o alvo `make pkg`; a compilação requer o ambiente de desenvolvimento instalado.

## Compatibilidade informada

O usuário informou software do sistema 4.88 e HEN 3.9.0. A página PS3Xploit lista HEN v3.4.2 para HFW 4.88; não foi possível confirmar a identificação “3.9.0” nas fontes oficiais consultadas. Ver `docs/compatibilidade-488.md`. Não atualizar ou reinstalar o console para resolver essa dúvida.

## Próximo passo

Executar o workflow manual no GitHub Actions para compilar o entry point contra uma revisão real do PSL1GHT e produzir ELF/SELF/PKG. Se a compilação passar, instalar o pacote no PS3 e testar inicialização RSX, navegação pelo DualShock 3, retorno ao XMB e encerramento. A versão 2.3 ainda não foi compilada no SDK real nem testada no console.

## Segurança

- Nunca compartilhar a chave privada WireGuard.
- Não colocar chaves reais em logs, capturas de tela ou no repositório.
- Usar `config/wireguard.example.conf` somente como modelo fictício.
- Não exibir “Conectado” até confirmar handshake e tráfego real pelo túnel.
- Não alegar proteção global sem validar tráfego de vários aplicativos e o comportamento fail-closed.

## Versão 0.4 — modelo de interface

Adicionados `include/ui_model.h`, `src/ui_model.c` e `tests/test_ui_model.c`. O modelo cobre navegação por direcional, X e O, telas Início/Configuração/Diagnóstico e ações de Conectar/Desconectar. A camada é independente do renderizador gráfico.

**Limite:** esta versão ainda não contém renderização RSX/PSL1GHT, leitura real do DualShock 3, motor WireGuard, integração de rede global ou PKG. O estado `Conectado` só deverá ser atribuído por um resultado real do backend; a UI não simula uma conexão.

### Testar o núcleo em ambiente C comum

```sh
make -f Makefile.host test
```

Os executáveis produzidos por esse comando são testes de computador comum, não executáveis PS3.


## Versão 0.5 — layout por comandos de desenho

Adicionados `include/ui_view.h`, `src/ui_view.c` e `tests/test_ui_view.c`. O módulo converte o modelo da interface em comandos independentes de renderer para as telas Início, Configuração e Diagnóstico. Isso prepara a integração com Tiny3D/RSX sem amarrar o núcleo a uma API gráfica ainda não validada.

**Limite:** ainda não há renderer Tiny3D/RSX, aplicação PSL1GHT, entrada real do controle, ELF, SELF ou PKG. Os testes executados são testes C em ambiente host. Ver `docs/interface-v0.5.md` e `docs/renderer-integration.md`.

## Versão 0.6 — runtime de entrada e plano de teste no console

Adicionados `include/ui_runtime.h`, `src/ui_runtime.c` e `tests/test_ui_runtime.c`. O runtime transforma máscaras de teclas normalizadas em ações somente na borda de pressionamento, evitando que manter uma tecla pressionada repita navegação a cada quadro. O adaptador PSL1GHT/libpad ainda precisa mapear o relatório real do DualShock 3 para essas máscaras.

Adicionado `docs/ps3-hardware-test-plan.md` com roteiro de instalação, navegação e validação futura de VPN. Os testes executados nesta etapa são testes host; nenhum PKG foi produzido ou testado no console. A toolchain PS3 não está instalada neste ambiente. Consulte `docs/estado-do-projeto.md`.

## Versão 0.8 — adaptador de entrada PSL1GHT

Adicionados `include/ps3_pad_adapter.h`, `src/ps3_pad_adapter.c` e `tests/test_ps3_pad_adapter.c`. O adaptador converte os campos `BTN_UP`, `BTN_DOWN`, `BTN_LEFT`, `BTN_RIGHT`, `BTN_CROSS` e `BTN_CIRCLE` da estrutura `padData` em máscaras usadas pelo runtime. A leitura física do controle ainda deverá ser feita pelo futuro ponto de entrada PSL1GHT.

O teste novo usa um stub local de `io/pad.h`; ele verifica a lógica de conversão no host, mas não comprova compatibilidade binária com os headers reais do SDK nem funcionamento no DualShock 3. Foram executados cinco testes host com sucesso. Ainda não há aplicação PSL1GHT, renderer RSX/Tiny3D, ELF, SELF ou PKG. Ver `docs/ps3-pad-adapter.md` e `docs/estado-do-projeto.md`.

## Versão 0.7 — preparação de compilação remota

Adicionados workflows para executar os testes C em CI e para preparar/verificar a toolchain oficial ps3dev em GitHub Actions. O workflow PS3 é manual e ainda não compila a homebrew: serve para confirmar que o runner consegue construir e disponibilizar os compiladores PPU/SPU. A compilação do PKG só será adicionada depois de existir uma aplicação PSL1GHT real e testável.

O ambiente de execução desta conversa não conseguiu acessar `github.com` por DNS e não possui `ppu-gcc`, `spu-gcc` ou ferramentas de PKG. Por isso, não foi produzido SELF/PKG nesta versão. Ver `ci/README.md`.

## Versão 0.9 — interface de backend gráfico

Adicionados `include/ui_renderer.h`, `src/ui_renderer.c` e `tests/test_ui_renderer.c`.
A nova camada despacha os comandos CLEAR/RECT/TEXT/LINE para callbacks de um
backend gráfico e valida callbacks ausentes, argumentos inválidos e comandos
não reconhecidos. O teste host usa callbacks de gravação. Isso cria uma fronteira
limpa para Tiny3D, mas **não implementa ainda o backend Tiny3D/RSX** nem inicializa
o vídeo do PS3. Nenhum ELF, SELF ou PKG foi produzido. Ver
`docs/renderer-backend-v0.9.md`.


## Versão 1.0 — validação integral do renderer e pré-verificação do SDK

O `ui_renderer_submit` agora valida o quadro inteiro antes de executar qualquer
callback. Assim, um callback ausente, geometria inválida, texto sem terminação
NUL ou tipo de comando desconhecido impede o despacho completo, em vez de
produzir um quadro parcial. Foram adicionados os resultados
`UI_RENDER_INVALID_GEOMETRY` e `UI_RENDER_INVALID_COMMAND_DATA`.

Adicionado `tools/check-ps3-sdk.sh` e o alvo `make -f Makefile.host
ps3-sdk-preflight` para verificar variáveis de ambiente, compilador PPU,
utilitário SELF, arquivos PSL1GHT e instalação Tiny3D. O script é somente uma
verificação de dependências: não compila o aplicativo e não gera ELF, SELF ou
PKG. Ver `docs/ps3-sdk-preflight-v1.0.md`.

**Testes host:** seis executáveis compilados com `-std=c11 -Wall -Wextra
-Werror -pedantic` e executados com sucesso. Não houve compilação PPU nem teste
no PS3.


## Versao 1.1 — preflight separado por etapa

O verificador do SDK agora possui tres modos: `--core` (toolchain PPU e bibliotecas PSL1GHT de controle/sysutil), `--graphics` (core + Tiny3D) e `--package` (graphics + ferramentas e metadados de SELF/PKG). O alvo `make -f Makefile.host ps3-sdk-preflight` executa o modo mais completo. O teste `tests/test_sdk_preflight.sh` usa um ambiente simulado para confirmar que cada modo exige apenas suas dependencias declaradas e que o modo de pacote falha quando faltam ferramentas.

**Limite:** esta versao melhora o diagnostico do ambiente remoto, mas ainda nao contem entry point PSL1GHT, backend Tiny3D, ELF, SELF ou PKG. O teste simulado nao substitui a verificacao com o SDK real.


## Versão 1.2 — preparação do runtime PSL1GHT

Adicionada `docs/ps3-runtime-integration-v1.2.md`, que define o ciclo de vida obrigatório do aplicativo e a sequência de integração com PSL1GHT/Tiny3D. A pesquisa técnica confirmou que o PSL1GHT exige callback para encerramento pelo XMB e que Tiny3D é uma dependência separada. Também foi identificado um relato de falha de framebuffer em hardware real; por isso, o primeiro teste físico deverá ser apenas de interface, sem VPN.

**Limite:** não foram adicionadas chamadas PSL1GHT não verificadas nem criado um falso `main`. Esta versão não gera ELF, SELF ou PKG. O entry point será escrito depois de fixarmos e compilarmos uma revisão concreta do SDK. Ver `docs/estado-do-projeto.md`.


## Versão 1.3 — evidência de toolchain no CI

O workflow manual `PS3 toolchain bootstrap check` agora prepara o ambiente ps3dev/PSL1GHT, exporta `PS3DEV`, `PSL1GHT` e `PORTLIBS`, executa o verificador do projeto no modo `--core` e publica o log como artefato do GitHub Actions. Isso torna verificável a instalação do compilador PPU e dos componentes básicos do SDK no runner.

**Limite:** o workflow não compila o VPN Manager e não gera ELF, SELF ou PKG. Ele ainda não instala Tiny3D nem valida o backend gráfico. Para obter o resultado, o workflow precisa ser executado no GitHub; não foi executado nesta sessão. Ver `docs/estado-do-projeto.md`.

## Versão 1.4 — robustez da preparação remota

O workflow manual foi ajustado para definir `PS3DEV`, `PSL1GHT` e `PORTLIBS` antes de compilar, criar o prefixo `/usr/local/ps3dev` com permissões para o usuário do runner e preservar o log de `build-all.sh` como artefato. A alteração segue o fluxo de configuração documentado pelo projeto ps3dev, que recomenda definir as variáveis de ambiente e garantir que o prefixo seja gravável antes da compilação. <https://github.com/ps3dev/ps3dev>

**Limite:** a mudança melhora a preparação e o diagnóstico do CI, mas não representa uma compilação já executada. O workflow continua sem compilar o VPN Manager e não gera ELF, SELF ou PKG. Ver `docs/estado-do-projeto.md`.


## Versão 1.5 — validação de dependências gráficas

O workflow manual foi ampliado para clonar Tiny3D, registrar a revisão exata obtida e compilar/instalar somente `lib` e `libfont`, sem tentar construir os samples opcionais. O novo script `tools/install-tiny3d.sh` valida a estrutura do repositório, executa as duas instalações e exige `tiny3d.h`, `libtiny3d.a`, `libfont.h` e `libfont.a`. O preflight `--graphics` agora verifica os quatro artefatos.

Foi adicionado `tests/test_tiny3d_install.sh`, que simula os comandos `make` e verifica o contrato do instalador sem fingir que compilou Tiny3D real. O teste de preflight também foi atualizado para exigir os arquivos da biblioteca de fontes. O workflow registra as revisões dos repositórios ps3dev e Tiny3D nos artefatos para que uma execução possa ser auditada. As branches ainda são obtidas por `--depth 1`; as revisões ficam registradas, mas ainda não são fixadas por hash no workflow.

**Limite:** o workflow não foi executado nesta sessão. A instalação real das bibliotecas, a compilação PPU do aplicativo e a geração ELF/SELF/PKG continuam pendentes. Ver `docs/estado-do-projeto.md` e `docs/tiny3d-ci-v1.5.md`.


## Versão 1.6 — referências selecionáveis para o CI

O workflow manual agora aceita referências explícitas para `ps3dev` e Tiny3D (branch, tag ou SHA), faz `fetch` da referência selecionada e registra o commit efetivo de cada repositório. Isso permite repetir uma compilação com os mesmos SHAs depois que uma execução bem-sucedida identificar revisões compatíveis. Foram adicionados valores padrão (`main` para ps3dev e `master` para Tiny3D), mantendo a possibilidade de informar hashes imutáveis na execução manual.

Adicionado `tests/test_workflow_contract.sh`, que verifica a presença dos parâmetros, fetch das referências, registro dos commits e publicação dos artefatos. O teste verifica o contrato textual do workflow; não executa GitHub Actions nem prova que a toolchain compila.

**Limite:** nenhuma execução remota foi realizada nesta sessão. O projeto continua sem entry point PSL1GHT, ELF, SELF, PKG ou VPN funcional.

## Versão 1.7 — probe de headers Tiny3D/PPU

Adicionados `tools/tiny3d_header_probe.c` e `tools/check-tiny3d-headers.sh`. Após instalar Tiny3D/libfont, o workflow executa `ppu-gcc -fsyntax-only` sobre uma unidade de tradução que inclui `tiny3d.h` e `libfont.h`. Isso verifica a compatibilidade sintática dos headers com o compilador PPU no ambiente remoto, sem alegar linkedição ou execução gráfica. Foi adicionado um teste host que simula o compilador e confirma os argumentos do probe. Ver `docs/tiny3d-header-probe-v1.7.md`.

**Limite:** esta versão ainda não contém entry point PSL1GHT, backend Tiny3D, ELF, SELF, PKG ou VPN funcional. A verificação real depende de executar o workflow no GitHub.


## Versão 1.8 — documentação do primeiro quadro RSX e correção de metadados

Corrigida a identificação da versão no README e no estado do projeto: o pacote
anterior já continha as verificações adicionadas na versão 1.7, mas o README
e `docs/estado-do-projeto.md` ainda declaravam 1.6. Adicionado
`docs/rsx-first-frame-v1.8.md`, que registra a sequência de inicialização e
apresentação de quadros RSX conforme a documentação pública do PSL1GHT.
Também foi acrescentado um teste de consistência dos metadados de versão.

**Limite:** esta versão não implementa a inicialização RSX nem desenha no
console. O documento é uma especificação de integração baseada na API
documentada; o primeiro quadro real ainda depende de um sample compilável
com a toolchain e de validação no hardware.


## Versão 1.9 — higiene do pacote e precisão do estado

Corrigida a versão desatualizada no resumo do estado do projeto. Os executáveis
produzidos pelos testes host foram removidos do pacote de distribuição; eles
serão recriados localmente ao executar `make -f Makefile.host test`.

O teste de metadados agora verifica também a versão do resumo principal. Esta
versão não acrescenta um executável PSL1GHT: a documentação oficial confirma
que os samples do SDK são compilados individualmente por seus Makefiles e que
a geração de SELF/PKG depende desse fluxo real. O próximo passo técnico é
compilar um sample gráfico oficial no workflow, antes de portar sua inicialização
para o aplicativo.


## Versão 2.0 — validação do sample RSX

O workflow passou a buscar uma revisão selecionada do PSL1GHT e compilar o sample gráfico `rsxtest`. Essa etapa era uma validação do SDK, não do aplicativo.

## Versão 2.1 — manifesto de evidências

Foi adicionado um manifesto SHA-256 para registrar artefatos e revisões do ambiente de compilação.

## Versão 2.2 — primeiro entry point do aplicativo

- Criada a pasta `app/` com Makefile PSL1GHT, metadados `TITLE`, `APPID`, `CONTENTID` e ícone `ICON0.PNG`.
- Criado `app/source/main.c` com `rsxInit`, buffers de vídeo, flip RSX e backend de desenho ligado ao despachante `ui_renderer`.
- Integrados leitura `ioPadGetInfo`/`ioPadGetData`, adaptador `ps3_pad_adapter`, `ui_runtime` e `ui_model`.
- Registrado callback `sysUtilRegisterCallback` para encerrar o loop quando o sistema solicita saída.
- Workflow atualizado para instalar a revisão selecionada do PSL1GHT, compilar o aplicativo, executar `make pkg`, validar os três arquivos e guardar hashes/logs.
- Adicionados testes de contrato e sintaxe do entry point com stubs no host.

**Limites:** os stubs não confirmam ABI nem linkagem com o SDK. O workflow ainda não foi executado. Nenhum ELF, SELF ou PKG foi gerado nesta sessão; nenhum teste foi realizado no console. O backend de desenho é inicial e não usa Tiny3D. A VPN não está implementada.
