#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
WORKFLOW="$ROOT/.github/workflows/ps3-toolchain-check.yml"
need() {
  grep -Fq -- "$1" "$WORKFLOW" || {
    printf 'ERRO: contrato ausente no workflow: %s\n' "$1" >&2
    exit 1
  }
}
need 'workflow_dispatch:'
need 'ps3dev_ref:'
need 'tiny3d_ref:'
need 'fetch --depth 1 origin "$PS3DEV_REF"'
need 'fetch --depth 1 origin "$TINY3D_REF"'
need 'rev-parse HEAD | tee "$GITHUB_WORKSPACE/ps3dev-revision.txt"'
need 'rev-parse HEAD | tee tiny3d-revision.txt'
need './tools/check-tiny3d-headers.sh'
need 'uses: actions/upload-artifact@v4'
printf 'OK: contrato do workflow remoto passou.\n'
