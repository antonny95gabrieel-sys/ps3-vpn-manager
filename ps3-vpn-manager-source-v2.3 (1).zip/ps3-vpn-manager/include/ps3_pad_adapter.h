#ifndef PS3_PAD_ADAPTER_H
#define PS3_PAD_ADAPTER_H

#include <stdint.h>
#include <io/pad.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Converte o relatório libpad do DualShock 3 para as máscaras do runtime.
 * A leitura do controle (ioPadGetData) continua sob responsabilidade do app.
 */
uint32_t ps3_pad_to_ui_keys(const padData *data);

#ifdef __cplusplus
}
#endif
#endif
