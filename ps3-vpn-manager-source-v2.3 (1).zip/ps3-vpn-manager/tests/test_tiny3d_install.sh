#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=${TMPDIR:-/tmp}/ps3-vpn-tiny3d-test-$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP/source/lib" "$TMP/source/libfont" "$TMP/bin" "$TMP/portlibs/include" "$TMP/portlibs/lib" "$TMP/ps3dev"
printf '# fake parent makefile\n' > "$TMP/source/Makefile"
printf '# fake lib makefile\n' > "$TMP/source/lib/Makefile"
printf '# fake font makefile\n' > "$TMP/source/libfont/Makefile"
cat > "$TMP/bin/make" <<'MAKE'
#!/bin/sh
set -eu
case "$*" in
  *"lib install"*) : > "$PORTLIBS/include/tiny3d.h"; : > "$PORTLIBS/lib/libtiny3d.a" ;;
  *"libfont install"*) : > "$PORTLIBS/include/libfont.h"; : > "$PORTLIBS/lib/libfont.a" ;;
  *) echo "invocacao inesperada de make: $*" >&2; exit 1 ;;
esac
MAKE
chmod +x "$TMP/bin/make"
PATH="$TMP/bin:$PATH" PS3DEV="$TMP/ps3dev" PSL1GHT="$TMP/psl1ght" PORTLIBS="$TMP/portlibs" \
  "$ROOT/tools/install-tiny3d.sh" "$TMP/source"
printf 'OK: teste de instalacao Tiny3D passou.\n'
