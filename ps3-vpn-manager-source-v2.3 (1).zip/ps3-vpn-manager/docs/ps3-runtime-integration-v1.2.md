# Integração do runtime PSL1GHT — v1.2

## Resultado desta etapa

Esta etapa fixa a fronteira entre o núcleo portátil já testado e o futuro executável GameOS. Não adiciona chamadas PSL1GHT especulativas: o repositório ainda não foi compilado contra headers reais nesta sessão.

## Ciclo obrigatório do aplicativo

1. Inicializar o subsistema gráfico e obter um framebuffer válido.
2. Inicializar libpad e abrir o dispositivo do controle.
3. Registrar o callback de encerramento solicitado pelo XMB.
4. Inicializar `ui_model_t` e `ui_runtime_t`.
5. Em cada quadro: ler o controle, converter `padData` com `ps3_pad_to_ui_keys`, chamar `ui_runtime_update`, construir a vista e despachar os comandos para o backend gráfico.
6. Ao receber encerramento: parar o loop, fechar o controle e liberar os recursos gráficos antes de sair.

A ordem exata de inicialização, nomes de funções e assinatura dos callbacks devem ser copiados dos headers e de um sample PSL1GHT da mesma revisão instalada. Não se deve adivinhar protótipos nem misturar exemplos de PSL1GHT V1 e V2.

## Decisão gráfica

Tiny3D é uma biblioteca separada que depende do PSL1GHT e instala `tiny3d.h` e `libtiny3d.a` em `PORTLIBS`. O README do projeto lista exemplos de sprites 2D e fontes. A integração deve começar por um quadro estático com texto e retângulos, antes de ligar o renderer genérico `ui_renderer`.

## Risco de hardware

A documentação do PSL1GHT descreve o fluxo RSX de framebuffer/flip, mas existe um relato público de falha de inicialização de framebuffer em hardware real (issue #144). Portanto, uma compilação bem-sucedida não será considerada prova de que a tela funciona no Super Slim. O primeiro PKG de teste, quando existir, deve validar apenas inicialização, desenho, controle e saída XMB — sem VPN.

## Sequência de integração

- [ ] Fixar a revisão da toolchain PSL1GHT usada pelo build.
- [ ] Compilar um sample oficial de vídeo/entrada no mesmo runner.
- [ ] Criar `src/ps3_main.c` usando somente protótipos confirmados nos headers dessa revisão.
- [ ] Criar backend Tiny3D para `UI_DRAW_CLEAR`, `UI_DRAW_RECT`, `UI_DRAW_LINE` e `UI_DRAW_TEXT`.
- [ ] Compilar ELF e SELF.
- [ ] Gerar PKG com metadados próprios e verificar a estrutura do pacote.
- [ ] Testar no PS3: abrir pelo XMB, desenhar, navegar, abrir XMB durante execução e sair sem travamento.

## Critério de conclusão

A etapa só estará concluída quando o ELF/SELF/PKG for gerado por toolchain real e o pacote for instalado e executado no console. Os testes host atuais não cobrem RSX, libpad real, callback do XMB ou compatibilidade do HEN.

## Fontes técnicas consultadas

- PSL1GHT oficial: https://github.com/ps3dev/PSL1GHT — estrutura de samples, toolchain, geração ELF/SELF/PKG e callback de saída XMB.
- Tiny3D: https://github.com/wargio/tiny3D — dependência PSL1GHT, instalação de `tiny3d.h`/`libtiny3d.a` e exemplos 2D/fontes.
- Header RSX PSL1GHT: https://github.com/ps3dev/PSL1GHT/blob/master/ppu/include/rsx/rsx.h — fluxo de framebuffer e flip.
- Issue PSL1GHT #144: https://github.com/ps3dev/PSL1GHT/issues/144 — relato de falha de framebuffer em hardware real.


## Atualização — implementação inicial na versão 2.2

O entry point foi criado em `app/source/main.c`. Ele usa `rsxInit` e as APIs de flip do PSL1GHT atual, registra dois buffers de exibição, desenha comandos do `ui_view` por meio do `ui_renderer`, lê `padData` com libpad e registra `sysUtilRegisterCallback` para o evento `SYSUTIL_EXIT_GAME`. O Makefile `app/Makefile` define metadados e o alvo `pkg`.

O backend usa escrita direta no framebuffer e uma fonte bitmap 5x7; não é Tiny3D. A compilação com SDK PPU, a geração do pacote e o comportamento no console continuam pendentes. O workflow foi atualizado para tentar essas etapas e guardar ELF/SELF/PKG e manifesto SHA-256.
