#include <assert.h>
#include <stdio.h>
#include "ui_model.h"

int main(void)
{
    ui_model_t ui;
    ui_model_init(&ui);
    assert(ui.screen == UI_SCREEN_HOME);
    assert(ui.selection == 0u);
    assert(ui.vpn_state == VPN_STATE_DISCONNECTED);
    assert(ui_model_handle_button(&ui, UI_BUTTON_CROSS) == UI_ACTION_CONNECT);
    assert(ui_model_handle_button(&ui, UI_BUTTON_DOWN) == UI_ACTION_NONE);
    assert(ui.selection == 1u);
    assert(ui_model_handle_button(&ui, UI_BUTTON_CROSS) == UI_ACTION_NONE);
    assert(ui_model_handle_button(&ui, UI_BUTTON_DOWN) == UI_ACTION_NONE);
    assert(ui_model_handle_button(&ui, UI_BUTTON_CROSS) == UI_ACTION_OPEN_CONFIGURATION);
    assert(ui.screen == UI_SCREEN_CONFIGURATION);
    assert(ui_model_handle_button(&ui, UI_BUTTON_CIRCLE) == UI_ACTION_BACK);
    assert(ui.screen == UI_SCREEN_HOME);
    assert(ui_model_connection_summary(&ui)[0] == 'D');
    puts("OK: navegacao e acoes da interface verificadas");
    return 0;
}
