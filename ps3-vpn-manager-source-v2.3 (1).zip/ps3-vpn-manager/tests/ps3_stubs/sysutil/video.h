#ifndef TEST_VIDEO_H
#define TEST_VIDEO_H
#include <ppu-types.h>
#define VIDEO_PRIMARY 0
#define VIDEO_STATE_ENABLED 1
#define VIDEO_BUFFER_FORMAT_XRGB 0
#define GCM_FLIP_VSYNC 2
typedef struct { u16 width, height; } videoResolution;
typedef struct { u8 resolution, scanMode, conversion, aspect; u8 padding[2]; u16 refreshRates; } videoDisplayMode;
typedef struct { u8 state, colorSpace; u8 padding[6]; videoDisplayMode displayMode; } videoState;
typedef struct { u8 resolution, format, aspect; u8 padding[9]; u32 pitch; } videoConfiguration;
s32 videoGetState(s32 output, s32 device, videoState *state);
s32 videoGetResolution(s32 id, videoResolution *resolution);
s32 videoConfigure(s32 output, videoConfiguration *config, void *option, s32 blocking);
#endif
