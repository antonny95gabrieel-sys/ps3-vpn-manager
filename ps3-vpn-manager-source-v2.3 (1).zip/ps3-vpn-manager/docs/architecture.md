# Decisões arquiteturais

## Interface XMB
O primeiro alvo é um aplicativo homebrew normal, exibido na categoria Jogo do XMB. “Integrado ao XMB” significa iniciável pelo XMB; não significa modificar a interface nativa do sistema.

## Separação de responsabilidades
- UI: exibe estado e recebe comandos do usuário.
- Controller: coordena configuração, inicialização, desligamento e monitoramento.
- WireGuard engine: implementa o protocolo e o transporte.
- System network adapter: integra o túnel ao encaminhamento global do GameOS.

## Risco técnico principal
Um aplicativo GameOS comum não ganha automaticamente autoridade para substituir a rota padrão de todo o sistema. O suporte a sockets no PSL1GHT permite aplicações de rede, mas não prova a existência de uma API pública para redirecionamento global. Será necessário um estudo específico de HEN/LV2 e testes controlados. Se isso não for possível com segurança, a alternativa funcional é usar um roteador VPN externo.

## Critérios para declarar conexão global funcional
1. Handshake WireGuard confirmado.
2. Endereço público observado corresponde ao endpoint de saída VPN.
3. DNS não escapa pelo caminho normal.
4. Tráfego de mais de um aplicativo do console passa pelo túnel.
5. Ao interromper o túnel, não há tráfego em claro (kill switch).
6. Reconexão e reinicialização não deixam rotas inconsistentes.
