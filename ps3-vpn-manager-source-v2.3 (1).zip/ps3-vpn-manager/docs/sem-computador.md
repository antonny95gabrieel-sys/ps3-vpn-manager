# Fluxo de trabalho sem computador local

O usuário informou que não dispõe de computador. Isso não impede a elaboração do código e da documentação, mas impede que ele próprio execute a toolchain PSL1GHT localmente.

Fluxo previsto:
1. Desenvolver e revisar o código-fonte neste ambiente.
2. Quando houver uma toolchain PS3 disponível no ambiente de compilação, compilar e verificar o SELF/PKG.
3. Não declarar compatibilidade sem teste no PS3 Super Slim com o firmware/HEN exatos.
4. Entregar um PKG somente depois de confirmar que ele foi realmente gerado e que os metadados/arquivos estão presentes.
5. Para transferência sem PC, avaliar download direto pelo navegador do PS3 ou instalação por USB preparada em outro dispositivo.

Um ZIP de código-fonte não é instalável pelo Package Manager do PS3.
