#!/bin/sh
set -eu

MODE=${1:---graphics}
case "$MODE" in
  --core|--graphics|--package) ;;
  *) printf 'Uso: %s [--core|--graphics|--package]\n' "$0" >&2; exit 2 ;;
esac

fail() { printf 'ERRO: %s\n' "$1" >&2; exit 1; }
need_file() { [ -f "$1" ] || fail "arquivo ausente: $1"; }
need_cmd() { command -v "$1" >/dev/null 2>&1 || fail "comando ausente no PATH: $1"; }

: "${PS3DEV:?Defina PS3DEV para a raiz do ambiente ps3dev}"
: "${PSL1GHT:?Defina PSL1GHT para a instalacao do PSL1GHT}"
: "${PORTLIBS:=$PS3DEV/portlibs/ppu}"

need_cmd ppu-gcc
need_file "$PSL1GHT/ppu_rules"
need_file "$PSL1GHT/base_rules"
need_file "$PSL1GHT/ppu/include/io/pad.h"
need_file "$PSL1GHT/ppu/include/sysutil/sysutil.h"
need_file "$PSL1GHT/ppu/lib/libio.a"
need_file "$PSL1GHT/ppu/lib/libsysutil.a"

printf 'OK: toolchain PPU e bibliotecas basicas PSL1GHT encontradas.\n'
printf 'PPU: '
ppu-gcc --version | sed -n '1p'
printf 'PS3DEV=%s\nPSL1GHT=%s\nPORTLIBS=%s\n' "$PS3DEV" "$PSL1GHT" "$PORTLIBS"

if [ "$MODE" = "--graphics" ] || [ "$MODE" = "--package" ]; then
  need_file "$PORTLIBS/include/tiny3d.h"
  need_file "$PORTLIBS/lib/libtiny3d.a"
  need_file "$PORTLIBS/include/libfont.h"
  need_file "$PORTLIBS/lib/libfont.a"
  printf 'OK: Tiny3D e libfont encontrados.\n'
fi

if [ "$MODE" = "--package" ]; then
  need_cmd make_self_npdrm
  need_cmd sprxlinker
  need_cmd sfo
  need_cmd pkg
  need_cmd package_finalize
  need_file "$PS3DEV/bin/sfo.xml"
  need_file "$PS3DEV/bin/ICON0.PNG"
  printf 'OK: ferramentas e metadados de empacotamento encontrados.\n'
fi

printf 'NOTA: preflight nao compila a aplicacao nem garante execucao no console.\n'
