#include "ps3_pad_adapter.h"
#include "ui_runtime.h"

uint32_t ps3_pad_to_ui_keys(const padData *data)
{
    uint32_t keys = 0u;

    if (data == 0) return 0u;

    if (data->BTN_UP)     keys |= UI_KEY_UP;
    if (data->BTN_DOWN)   keys |= UI_KEY_DOWN;
    if (data->BTN_LEFT)   keys |= UI_KEY_LEFT;
    if (data->BTN_RIGHT)  keys |= UI_KEY_RIGHT;
    if (data->BTN_CROSS)  keys |= UI_KEY_CROSS;
    if (data->BTN_CIRCLE) keys |= UI_KEY_CIRCLE;

    return keys;
}
