# Preflight do SDK PS3 — v1.1

O verificador foi dividido em tres etapas para nao confundir uma toolchain PPU funcional com a disponibilidade de grafico ou empacotamento.

- `--core`: `ppu-gcc`, regras PSL1GHT, headers e bibliotecas basicas de `libio` e `libsysutil`.
- `--graphics`: tudo de `--core`, mais `tiny3d.h`, `libtiny3d.a`, `libfont.h` e `libfont.a` em `PORTLIBS` (a verificação foi ampliada na versão 1.5).
- `--package`: tudo de `--graphics`, mais `make_self_npdrm`, `sprxlinker`, `sfo`, `pkg`, `package_finalize`, `sfo.xml` e `ICON0.PNG`.

Exemplo:

```sh
export PS3DEV=/usr/local/ps3dev
export PSL1GHT="$PS3DEV/psl1ght"
export PORTLIBS="$PS3DEV/portlibs/ppu"
export PATH="$PS3DEV/bin:$PS3DEV/ppu/bin:$PSL1GHT/host/bin:$PATH"
./tools/check-ps3-sdk.sh --core
./tools/check-ps3-sdk.sh --graphics
./tools/check-ps3-sdk.sh --package
```

O modo `--package` verifica apenas a presenca das ferramentas. Nao garante que o Makefile da aplicacao esteja correto, que o SELF seja aceito pelo console, que o PKG seja instalavel ou que o HEN o execute. Isso so pode ser confirmado com build real e teste no PS3.
